import { beforeAll, afterEach, expect, it, vi } from 'vitest'
import {webcrypto} from 'node:crypto'
import {writeFileSync} from 'node:fs'
import {BalloonsController} from '/Users/renzo/Documents/Assessment Practice/App/src/balloons/controller'
import {BalloonsStore, acquireOwner, type Root, type Backend} from '/Users/renzo/Documents/Assessment Practice/App/src/balloons/storage'
import {loadScoredManifests} from '/Users/renzo/Documents/Assessment Practice/App/src/balloons/manifests'
import {loadDrillManifests} from '/Users/renzo/Documents/Assessment Practice/App/src/balloons/drill-manifests'
import {eligibleRoot} from '/Users/renzo/Documents/Assessment Practice/App/src/balloons/retest-test-support'
import {advance} from '/Users/renzo/Documents/Assessment Practice/App/src/balloons/durable'
import type {FormId} from '/Users/renzo/Documents/Assessment Practice/App/src/balloons/contracts'
beforeAll(async()=>{Object.defineProperty(globalThis,'crypto',{value:webcrypto,configurable:true});await loadScoredManifests();await loadDrillManifests()})
afterEach(()=>{vi.restoreAllMocks();vi.unstubAllGlobals();document.body.innerHTML=''})
function env(form:FormId='BL1'){
 let root=eligibleRoot(form); const frames:FrameRequestCallback[]=[];let mounts=0
 Object.defineProperty(navigator,'locks',{configurable:true,value:{request:(_n:string,_o:unknown,cb:(l:object)=>unknown)=>Promise.resolve(cb({}))}})
 Object.defineProperty(document,'visibilityState',{configurable:true,value:'visible'})
 vi.stubGlobal('requestAnimationFrame',(cb:FrameRequestCallback)=>{frames.push(cb);return frames.length});vi.stubGlobal('cancelAnimationFrame',()=>{})
 const backend:Backend={read:async()=>structuredClone(root),change:async(fn,signal)=>{if(signal?.aborted)throw new DOMException('Canceled','AbortError');const next=structuredClone(root),result=fn(next);next.revision++;root=structuredClone(next);return structuredClone(result)}}
 const store=new BalloonsStore(backend,'install')
 const c=new BalloonsController(store,()=>{},()=>{mounts++;const e=document.createElement('div');e.innerHTML='<b data-balloon-type>Type</b><button data-control="pump"></button><button data-control="collect"></button>';document.body.append(e);e.getBoundingClientRect=()=>({width:10,height:10}) as DOMRect;return e})
 return {c,store,frames,root:()=>root,mounts:()=>mounts,rt:()=>Object.values(root.records).filter(r=>r.header.retest).at(-1)!}
}
async function frames(e:ReturnType<typeof env>,n:number){await vi.waitFor(()=>expect(e.mounts()).toBe(n));e.frames.shift()!(1);e.frames.shift()!(2)}
async function act(e:ReturnType<typeof env>,kind:'collect'|'next'|'pump'){const s=e.c.view.record!.snapshot.core;return e.c.action(kind,'keyboard',s.round,s.revision)}
it('round-two interruption before confirmation should retain a clean resumable checkpoint',async()=>{
 const e=env();await e.c.explainRetest('base');const start=e.c.startRetest();await frames(e,1);await start
 await act(e,'collect');const next=act(e,'next');await vi.waitFor(()=>expect(e.mounts()).toBe(2));await e.c.pause('browser_interruption');await next
 writeFileSync('/private/tmp/balloons-c1-repair/final/round-two-interruption.json',JSON.stringify({root:e.root(),view:e.c.view},null,2))
 expect(e.rt().snapshot.phase).toBe('paused');expect(e.rt().snapshot.comparisonEligible).toBe(true)
 await e.c.dispose()
})
for(const bl of ['BL1','BL2','BL3'] as FormId[])for(const rt of [1,2,3])it(`independent whole result and closure ${bl}/RT${rt}`,async()=>{
 const e=env(bl);const release=await acquireOwner(new AbortController().signal);e.store.bindOwner('audit',release)
 let n=2000000;const t=()=>({wallTimeMs:++n,monotonicMs:n,clockEpochId:'audit'});let r:any,token:any
 for(let attempt=1;attempt<=rt;attempt++){
  ({record:r,token}=await e.store.reserveRetest('audit','base',t(),'audit',attempt>1))
  r=await e.store.commit(token,r,{kind:'arm'},t())
  if(attempt<rt)r=await e.store.commit(token,r,{kind:'pause',reason:'interrupted'},t())
 }
 r=await e.store.commit(token,r,{kind:'confirm'},t());expect(r.header.formId).toBe('RT'+rt)
 const expected=[];let banked=0,lost=0
 for(const row of r.snapshot.core.manifest.rounds){const k=row.round%3===0?32:row.round%3===1?3:0;const burst=row.threshold<=k;const successes=burst?row.threshold-1:k;expected.push({outcome:burst?'burst':k===32?'cap_collect':'voluntary_collect',successfulPumps:successes,bankedCents:burst?0:5*k,lostCents:burst?5*successes:0});banked+=burst?0:5*k;lost+=burst?5*successes:0}
 while(r.snapshot.core.status!=='completed'){
  const s=r.snapshot.core,k=s.round%3===0?32:s.round%3===1?3:0,kind=s.status==='resolved'?'next':s.current.successfulPumps<k?'pump':'collect',time=t();const a={kind,actionId:s.nextActionId,expectedRevision:s.revision,expectedRound:s.round,source:'keyboard',time} as const
  r=await e.store.commit(token,r,{kind:'action_pending',action:a},time);r=await e.store.commit(token,r,{kind:'action',action:a},time)
  if(kind==='next'){r=await e.store.commit(token,r,{kind:'arm'},t());r=await e.store.commit(token,r,{kind:'confirm'},t())}
 }
 expect(r.snapshot.core.bankedCents).toBe(banked);expect(r.snapshot.core.lostCents).toBe(lost)
 for(let i=0;i<39;i++)expect(r.snapshot.core.results[i]).toMatchObject(expected[i])
 expect(r.header.identity.mapping).toEqual(e.root().records.base.header.identity.mapping);expect(r.header.settings).toEqual(e.root().records.base.header.settings)
 expect(e.root().training!.chains.chain.completedRetestSessionId).toBe(r.header.identity.sessionId)
 await expect(e.store.reserveRetest('audit','base',t(),'audit',true)).rejects.toThrow('closed')
 writeFileSync(`/private/tmp/balloons-c1-repair/final/pair-${bl}-RT${rt}.json`,JSON.stringify(e.root()));await release()
})
it('generate three admitted chain seeds for browser probes',()=>{for(const f of ['BL1','BL2','BL3'] as FormId[])writeFileSync(`/private/tmp/balloons-c1-repair/final/seed-${f}.json`,JSON.stringify(eligibleRoot(f)))})
