export default {test:{environment:'jsdom',include:['/private/tmp/balloons-c1-repair/audit/*.test.ts'],testTimeout:30000}}
