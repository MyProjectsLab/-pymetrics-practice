# Independent Balloons B2-C1 exact-SHA audit

**Verdict: FAIL for the focused C1 reservation/play scope. Two reproducible defects remain.**

Target: `acece735e487c0a0bcea48faab2c36c064a11123`  
Required and verified immediate parent: `d1a40ceded441491142dd1ccd6bb8b6c21afd796`  
Audit date: 2026-10-04, America/New_York.

## Identity and read-only boundary

Initial and final HEAD/parent match. Both worktree status checks are empty. All **837 tracked files** remain byte-identical to the initial SHA-256 inventory. A `git archive` of the target matched those same files before testing, and its original tracked source files still match after testing. No repository file, branch, index, dependency, specification or tracker was edited. No repair, commit, push, deployment or release occurred.

Tests, builds, browser profiles and audit harnesses ran outside the repository under this directory. Installed dependencies were copied with copy-on-write into the archive. The aggregate repository check ran before the independent harnesses were added. Localhost preview and headless Chromium required sandbox escalation; both were approved. These were local disposable test sessions.

Evidence: [initial file hashes](evidence/initial-hashes.json), [final identity and unchanged-file check](evidence/final-state.json), [tested build hashes](evidence/build-hashes.json).

Read AGENTS.md, the complete Master Strategy, Balloons V1.0 specification and both review files, freeze record, tracker, B2-B original and repair verification, retained focused independent PASS, and C1 verification. Both JSON companions parse. All five frozen packet hashes match their approved freeze values; no new external source or specification interpretation was substituted. [Frozen hashes](evidence/frozen-hashes.json).

## F1 — P1: prior-round onset prevents a durable pause on a later round

Locations: `src/balloons/controller.ts:140` and `src/balloons/controller.ts:219–224`; recovery consequence at `src/balloons/durable.ts:112–114`.

Reproduction:

1. Open an eligible chain, reserve RT1 and confirm its first balloon.
2. Collect round 1 and accept Next. Hold the round-2 animation-frame confirmation after round 2 has durably armed and mounted.
3. Deliver blur, then release the held callbacks. No storage failure or unresolved action is injected.
4. Select **Check and resume saved session**.

Observed: the UI says paused, but durable storage remains `phase: presentation_armed`, round 2, `pendingAction: null`, with only round 1 in `confirmedRounds`. Recovery keeps the same RT/session and action prefix but changes `comparisonEligible` to false. The browser visibly labels it **“Review only; not eligible to complete a training chain.”** This consumes a scarce RT without allowing the otherwise intact attempt to close its chain.

Cause: `onset` survives the previous round and is matched only by session owner-token identity. The cleanup path tries to confirm the new armed round using round 1's earlier timestamp. `advance` rejects the regressing monotonic timestamp. The broad catch suppresses that exception before a pause checkpoint can be committed; subsequent recovery correctly rejects eligibility without that checkpoint. The source of the failure is the stale onset, not a storage outage. Onset retention must be scoped to the actual presentation/round, and absence of a new confirmation must still permit a clean pause of an already-exposed intact session.

The independent controller assertion fails (`presentation_armed` versus expected `paused`), and the production browser independently reproduces both the durable state and visible ineligibility. Frozen §§5–6 permit same-session interruption recovery; later-round presentation must not fabricate first-round confirmation evidence.

Evidence: [controller test](source/audit/independent.test.ts), [failure log](evidence/independent.log), [browser driver](browser-final.mjs), [before-resume root](evidence/round-two-before-resume.json), [after-resume root](evidence/round-two-after-resume.json), [visible text](evidence/round-two-after-resume.txt), [screenshot](evidence/round-two-after-resume.png).

## F2 — P1: leaving during ownership acquisition leaks the browser owner lock

Locations: `src/balloons/controller.ts:52–61`, `src/balloons/controller.ts:187–198`, and `src/balloons/controller.ts:237–238`.

Reproduction:

1. From a completed assigned drill, choose **Open retest explanation**.
2. Hold delivery of the `navigator.locks.request` callback for the Balloons owner lock, before `begin()` receives its release function.
3. Choose **Pause and open history** while the controller awaits ownership.
4. Release the callback, then attempt to open the assigned exercise in another tab.

Observed: history is already open and no RT reservation was created, yet the canceled controller retains the installation owner lock. A second tab's `ifAvailable` check returns false; its actual exercise screen says **“Balloons is active in another tab. Pause or leave that session first.”** The old controller is no longer reachable through the journey's controller ref. Closing/reloading the owning document can clear the lock, but normal navigation did not.

Cause: acquisition now uses a separate `ownerScope`. Cancellation before `releaseOwner` exists aborts only the operation scope. The delayed acquisition subsequently binds the capability and assigns its release function, then `canceled(this.scope.signal)` throws. `failure()` returns immediately for that canceled scope without releasing the newly acquired lock. Separate positive-onset cleanup ownership can be retained where required, but a canceled pre-reservation acquisition must release its late result.

The independent controller test and production Chromium with actual Web Locks both fail the release assertion. The browser timing boundary is deliberately held; this audit does not claim a measured natural occurrence rate. The controller is also shared with Practice, making this an affected B1-B ownership regression as well as a C1 failure.

Evidence: [owner test](source/audit/owner.test.ts), [failure log](evidence/owner.log), [late-owner state](evidence/late-owner.json), [browser owner result](evidence/late-owner-browser.json), [blocked candidate text](evidence/late-owner-blocked-tab.txt), [blocked candidate screenshot](evidence/late-owner-blocked-tab.png), [supplementary browser log](evidence/late-owner-browser-final.log).

## Checked behavior and precise coverage

- **Current authority admission:** 18 independently written reservation/arming rejection tests pass. Missing BL or drill, deleted drill, missing/substituted first completion, a closed chain, changed baseline settings/mapping, and corrupted drill results reject without mutation. This exercises current durable dependencies, not stored developer expected flags. [Tests](source/audit/admission.test.ts), [log](evidence/admission-final.log).
- **Dynamic allocation and all nine actual pairings:** BL1–BL3 each complete RT1–RT3 under newly written independent expected arithmetic. Earlier RTs are made uncertain before requesting later forms. Original mapping/settings persist, each full result reconciles, exactly one completion closes the chain, and a later reservation rejects. These are synthetic admitted fixtures; they are not evidence of prior human play.
- **Three full browser RT forms:** RT1, RT2 and RT3 each complete 39 rounds through automated native Space button activation. Earlier armed/uncertain forms remain consumed; each completion has the correct actual form and one chain closure. Saved result and journal remain identical after reload once report-view persistence has completed.
- **Reservation/exposure:** browser checks pass unarmed release/reopen with the same unseen form and new session, exclusive ownership during explanation, post-arm expiry consuming the exact RT and invalidating it, conservative first-display uncertainty, failed action recovery, fresh RT retries and family exhaustion without chain closure. Source inspection and the freshly executed repository tests additionally cover pre-arm deadline/rollback, two-frame gating, exposure-write failure, stale capabilities and exact RT tombstones. F1 and F2 bound the interruption/cancellation verdict.
- **B1-B R1 regression:** a real final RT action commits while its transaction completion callback is withheld. The delivery watchdog rereads authority, reports verified saved completion, retains valid eligibility and exactly one chain lock. Releasing the old callback changes no bytes.
- **Deletion and late delivery:** Delete all during held exposure-confirmation delivery replaces the whole root, removes training, and remains byte-identical after callback release. Admission tests also cover missing/deleted dependencies. Existing repository deletion/installation-fence regressions pass. This does not resolve N1 or claim exhaustive callback invariance.
- **Ordinary recovery and B2-B adjacency:** a clean confirmed-round pause/resume retains the same session and eligibility. A fresh browser installation completes the real 39-round BL guide-to-report path, an 18-round assigned drill and retest admission. The UI reserves an unexposed RT only after drill completion. All seven drill inventories pass the repository verifier; a new independent seven-inventory browser audit was not repeated.

The final browser matrix has **14 cases: 12 PASS and the two findings above FAIL**. Browser assertions include page-error checks. A supplementary F2 run also captures the blocked candidate UI. [Final matrix](evidence/browser-results.json), [final browser log](evidence/browser-final.log), [driver](browser-final.mjs).

A separate Python reconciler imports no production code. It hashes all nine frozen scored manifests, checks profile counts/support/quartile/sum bands, and replays primitive accepted actions against the frozen thresholds. It independently matches complete round result objects, action IDs/revisions, visible mapping, cents, conservation, 39 confirmations, settings and closure. **14 completed sessions / 546 rounds pass**: nine adapter RT completions, three browser RT completions, the fresh browser BL, and the delayed-final-delivery RT. Synthetic BL seeds reused in pair files are excluded from this count. [Reconciler](reconcile.py), [per-session arithmetic](evidence/independent-arithmetic.json).

## Repository verification

`npm run check` passed **1,033 tests / 50 files**, lint, Stop form/drill checks, TypeScript and both production builds. `npm run balloons:check` passed all nine scored forms and seven fixed drill inventories. Target-to-parent `git diff --check` passed. The two existing lint warnings, SQLite experimental warning and bundle-size warning remain. The unchanged Stop focus assertion passed in this run; this does not resolve OBS-1's unexplained intermittent cause.

[Aggregate log](evidence/check.log), [manifest checks](evidence/manifests.log). The independent harness totals are **28 passing tests and 2 failing tests**, including one seed-generation check; nine passing tests each play a full RT. Those counts are separate from the repository suite.

## Reproduction

From `/private/tmp/balloons-c1-audit-acece73/source`:

```sh
./node_modules/.bin/vitest run --config audit/config.ts
./node_modules/.bin/vite preview --host 127.0.0.1 --port 4213
```

With the preview running, from `/private/tmp/balloons-c1-audit-acece73`:

```sh
node browser-final.mjs
python3 reconcile.py
```

For focused browser reproductions, set `AUDIT_CASE=round-two-interruption` or `AUDIT_CASE=late-owner-after-exit`. The driver records FAIL results in JSON/logs and deliberately completes the remaining scenarios; its process exit alone is not a pass criterion. The current full matrix and the separate focused F2 result are retained separately.

To repeat the original aggregate check without discovering audit-only tests, use a fresh target archive or temporarily place `source/audit/` outside this external source directory. Do not add these harnesses to the original repository for this read-only audit.

## Harness corrections and limits

Preliminary driver failures are retained and not counted as product defects: (1) a default rAF-based wait could not run while rAF was intentionally held; the probe now polls independently; (2) an unanchored BL1 selector also matched an RT whose label names baseline BL1; (3) a full-byte reload comparison read before asynchronous `report_viewed` persistence completed, while the snapshot and original journal prefix already matched; it now waits for the report screen; (4) a new loop had a syntax error before any browser ran; (5) one corruption probe tried to modify a frozen test fixture, corrected by cloning the fixture before mutation. None required a product change. The two real findings remain independently reproduced in both adapter and corrected production-browser probes.

Chromium is headless 145.0.7632.6 on this Mac using a disposable context. Keyboard input is automation-generated; frame/blur, callback and storage failures are injected bounded functional evidence. No physical keyboard/display timing, natural race frequency, screen-reader speech, native OS lifecycle, touch/Safari/device matrix or full accessibility qualification is established.

This FAIL covers only Balloons B2-C1 reservation/play and the described affected regressions at the named SHA. It does not grant founder acceptance, BL–RT comparison UI, N1, OBS-1, whole B1/mock, full B2, browser/device/accessibility qualification, deployment or release. Existing focused parent PASSes remain historical and are not extended to this SHA.
