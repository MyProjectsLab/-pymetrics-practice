import {defineConfig} from 'vitest/config'
export default defineConfig({test:{environment:'jsdom',include:['audit/*.test.ts'],testTimeout:30000}})
