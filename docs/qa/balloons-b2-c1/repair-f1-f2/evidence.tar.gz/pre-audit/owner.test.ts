import {it,expect,vi} from 'vitest'
import {webcrypto} from 'node:crypto'
import {BalloonsController} from '/Users/renzo/Documents/Assessment Practice/App/src/balloons/controller'
import {BalloonsStore, type Backend} from '/Users/renzo/Documents/Assessment Practice/App/src/balloons/storage'
import {loadScoredManifests} from '/Users/renzo/Documents/Assessment Practice/App/src/balloons/manifests'
import {loadDrillManifests} from '/Users/renzo/Documents/Assessment Practice/App/src/balloons/drill-manifests'
import {eligibleRoot} from '/Users/renzo/Documents/Assessment Practice/App/src/balloons/retest-test-support'
import {writeFileSync} from 'node:fs'
it('leaving during pending owner acquisition must release a late owner',async()=>{
 Object.defineProperty(globalThis,'crypto',{value:webcrypto,configurable:true});await loadScoredManifests();await loadDrillManifests();let root=eligibleRoot();let enter!:()=>void,locked=false
 Object.defineProperty(navigator,'locks',{configurable:true,value:{request:(name:string,_o:unknown,cb:(l:object)=>Promise<void>)=>{if(name.endsWith(':owner'))return new Promise<void>(resolve=>{enter=()=>{locked=true;void Promise.resolve(cb({})).then(()=>{locked=false;resolve()})}});return Promise.resolve(cb({}))}}})
 const backend:Backend={read:async()=>structuredClone(root),change:async fn=>{const next=structuredClone(root),r=fn(next);root=next;return r}}
 const c=new BalloonsController(new BalloonsStore(backend,'install'),()=>{},()=>{throw Error('no mount expected')})
 const pending=c.explainRetest('base');await vi.waitFor(()=>expect(enter).toBeDefined());await c.dispose();enter();await pending
 await new Promise(r=>setTimeout(r,5));writeFileSync('/private/tmp/balloons-c1-repair/pre/late-owner.json',JSON.stringify({locked,mode:c.view.mode,records:Object.keys(root.records)}))
 expect(locked).toBe(false)
})
