# C5 bounded repair verification
Start: clean c0fdc8e2f0800a22f536c6f053715e459967b1d2.
Before editing: full Chromium retest, ordinary completion save fails twice, view comparison, leave, other-tab baseline delete, Resume opens invalid comparison.

Repair boundaries:
- Preserve original chain installation authority independently of write availability.
- Re-read durable dependency/deletion/installation evidence on Resume and comparison entry; no cached notification-only admission.
- Reject unavailable authority without rewriting immutable reports.
- Fence stale eligibility responses against chain and navigation replacement.
- Preserve fully temporary same-tab chains and unrelated deletion controls.

Focused matrix: baseline / required drill / Delete all crossed with delivered / delayed / unavailable notifications, after settled failed completion and leaving; repeat Resume and reload. Include missing authority, restored authority, unrelated deletion and temporary controls. Real full-run controls supplement explicitly seeded boundary cases. Run affected C2-C4 completion/ownership fixtures and repository check once after focused tests pass. Record exact source hashes, journals, storage and limits. No specification edits, N2, S46, M6, deployment or acceptance.
