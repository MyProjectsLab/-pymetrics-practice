import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile,writeFile} from 'node:fs/promises';
const {chromium}=createRequire(import.meta.url)('/Users/renzo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const F=JSON.parse(await readFile('/private/tmp/stop-m5-full-audit-c0fdc8e-20261001/fixtures.json'));
const before=JSON.parse(await readFile('/private/tmp/stop-m5-c5-repair/pre-edit/delivered-before-none-report-fail.json'));
const retained=before.settled.results.find(r=>r.mode==='retest'&&r.storageMode==='temporary_memory');
const origin='http://127.0.0.1:5527/';
const browser=await chromium.launch({headless:true,executablePath:'/Users/renzo/Library/Caches/ms-playwright/chromium_headless_shell-1208/chrome-headless-shell-mac-arm64/chrome-headless-shell'});
const out={browser:browser.version(),method:'Seed actual pre-edit immutable failed-save journal and verified prerequisites at the post-fallback boundary; actual App, training, storage and history controls. No timed run or save-retry claim for these matrix cases.',cases:[],errors:[]};
const click=(p,name)=>p.getByRole('button',{name,exact:true}).click();
const ready=p=>p.getByRole('button',{name:'Open Stop',exact:true}).waitFor();
const api=(p,fn,arg)=>p.evaluate(async({fn,arg})=>{const S=await import('/src/stop/storage.ts'),T=await import('/src/stop/training.ts'),R=await import('/src/stop/run.ts');return new Function('S','T','R','s','x',`return (${fn})(S,T,R,s,x)`)(S,T,R,S.stopLocalStore()??window.auditStore,arg)},{fn:fn.toString(),arg});
const capture=p=>api(p,async(S,T,R,s)=>({body:document.body.innerText,chain:T.currentTrainingChain(),results:R.activeTabResults(),state:await s.read(),activity:await s.activities(),locks:await navigator.locks.query()}));
try {
for(const delivery of ['unavailable']) for(const deletion of ['read-unavailable','visible-deletion']) {
 const c=await browser.newContext({viewport:{width:1200,height:800}});
 await c.addInitScript(({delivery,F,retained})=>{window.fixture={F,retained};if(delivery==='unavailable')window.BroadcastChannel=undefined;
 if(delivery==='delayed'){const B=window.BroadcastChannel;window.messages=[];window.BroadcastChannel=class extends B{postMessage(m){window.messages.push(()=>super.postMessage(m))}}}}, {delivery,F,retained});
 const a=await c.newPage(),b=await c.newPage(); for(const p of [a,b])p.on('pageerror',e=>out.errors.push(String(e)));
 await a.route('**/src/main.tsx',async route=>{const response=await route.fetch();let body=await response.text();body=body.slice(0,body.indexOf('createRoot(document'))+`
 const S=await import('/src/stop/storage.ts'),T=await import('/src/stop/training.ts'),R=await import('/src/stop/run.ts');
 const {F,retained}=window.fixture; const s=await S.StopLocalStore.open();window.auditStore=s;
 await s.mutate(q=>{Object.assign(q,F.state);q.results[F.retest.sessionId]=F.retest;q.exposures[F.retest.form.id]={formId:F.retest.form.id,sessionId:F.retest.sessionId,exposedAtWall:F.retest.completedAtWall,visualProfile:'standard',deleted:false,certainty:'confirmed'}});
 S.setStopLocalStore(s);T.restoreTrainingChain(F.chain);S.setStopLocalStore(null);
 R.restoreStopRecords([F.baseline,retained],[]);T.updateTrainingChain({retest:retained,status:'complete',retestAttempts:[{sessionId:retained.sessionId,formId:retained.form.id,valid:true}]});
 createRoot(document.getElementById('root')).render(_jsxDEV(App,{storagePolicy:'temporary'},void 0,false,{},this));`;
 await route.fulfill({response,body});});
 await a.goto(origin);await ready(a);await b.goto(origin);await ready(b);
 await click(a,'Resume Stop training');await a.getByText('Overall accuracy changed from 25% to 25% (+0 percentage points).',{exact:true}).waitFor();

 const row={delivery,deletion,before:await capture(a)};
 if(deletion==='read-unavailable') {
  await click(a,'Back to library');await ready(a);
  await api(a,(S,T,R,s)=>{window.realRead=s.read.bind(s);s.read=async()=>{throw Error('Injected authority read unavailable')}});
  await click(a,'Resume Stop training');await a.getByRole('alert').filter({hasText:'Comparison unavailable'}).waitFor();
  assert(!(await a.locator('body').innerText()).includes('Overall accuracy changed'));
  await click(a,'Review temporary retest');await a.getByRole('heading',{name:'Your Stop practice result',exact:true}).waitFor();
  row.unavailableBody=await a.locator('body').innerText();assert(!row.unavailableBody.includes('This result is saved'));
  await api(a,(S,T,R,s)=>{s.read=window.realRead});
  row.review=await capture(a);assert.deepEqual(row.review.results.find(r=>r.sessionId===retained.sessionId),retained);
  await click(a,'Back to library');await click(a,'Resume Stop training');
  await a.getByText('Overall accuracy changed from 25% to 25% (+0 percentage points).',{exact:true}).waitFor();row.recovered=await capture(a);
 } else {
  await click(b,'Stop history');const target=b.locator('article.panel').filter({hasText:F.baseline.form.id}).first();
  await target.getByRole('button',{name:'Delete this result',exact:true}).click();await b.getByRole('alertdialog').getByRole('button',{name:'Delete this result',exact:true}).click();
  await b.getByRole('alertdialog').waitFor({state:'detached'});
  await a.getByText('Overall accuracy changed from 25% to 25% (+0 percentage points).',{exact:true}).waitFor({state:'detached',timeout:3000});
  row.after=await capture(a);assert.equal(row.after.chain,null);assert.deepEqual(row.after.results.find(r=>r.sessionId===retained.sessionId),retained);
  await click(a,'Review temporary retest');await a.getByRole('heading',{name:'Your Stop practice result',exact:true}).waitFor();row.review=await capture(a);
 }
 await a.unroute('**/src/main.tsx');await a.reload();await ready(a);row.reload=await capture(a);assert(!row.reload.results.some(r=>r.sessionId===retained.sessionId));
 row.pass=true;out.cases.push(row);console.log(delivery,deletion,'PASS');await c.close();
}
assert.deepEqual(out.errors,[]);
}catch(e){out.error=String(e.stack);console.error(e);process.exitCode=1}finally{await writeFile('/private/tmp/stop-m5-c5-repair/extra-boundaries.json',JSON.stringify(out,null,2));await browser.close()}
