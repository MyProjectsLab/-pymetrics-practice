import json,pathlib
root=pathlib.Path('/private/tmp/stop-m5-c5-repair')
out=[]
for folder in ['full-after','retry-control','c2-drill','c4-all']:
 p=next((root/folder).glob('*.json'));d=json.loads(p.read_text());assert not d.get('error'),(folder,d.get('error'));assert not d['errors']
 r=next(r for r in d['pending']['results'] if r['mode']=='retest' and r['sessionId'] not in [x['sessionId'] for x in d['deleted']['results'] if x['mode']=='retest']) if folder!='retry-control' else None
 # Use the completed source captured as the only new pending retest.
 ids=set(d['pending']['state']['results']);candidates=[x for x in d['pending']['results'] if x['mode']=='retest' and x['storageMode']=='temporary_memory'];assert len(candidates)==1;r=candidates[0]
 e=r['events'];assert len(e)==643;assert [x['sequenceNumber'] for x in e]==list(range(1,644));assert all(x['sessionId']==r['sessionId'] for x in e)
 assert sum(x['type']=='stimulus_presented' for x in e)==88;assert sum(x['type']=='trial_resolved' for x in e)==88
 assert r['summarySnapshot']['counts']=={'hits':0,'misses':60,'withholds':20,'falseAlarms':0};assert r['summarySnapshot']['rates']['overall']==.25
 assert d['pending']['locks']=={'held':[],'pending':[]};assert d['pending']['signalAborted']
 if folder=='full-after':
  assert d['settled']['saveCalls']==2;x=d['postFailureDeletion'];assert x['resumed']['chain'] is None;assert 'Overall accuracy changed' not in x['resumed']['body'];assert 'Comparison unavailable' in x['resumed']['body'];assert 'Review temporary retest' in x['resumed']['body']
  assert next(xr for xr in x['resumed']['results'] if xr['sessionId']==r['sessionId'])['events']==e
  assert r['sessionId'] not in x['durable']['state']['results'];assert x['afterReload']['chain'] is None
 elif folder=='retry-control':
  assert d['settled']['saveCalls']==2;assert d['settled']['chain']['status']=='complete';assert 'Overall accuracy changed' in d['resumed']['body'];assert d['historyAction']==1
  for q in [d['durable'],d['reload']]: assert q['state']['results'][r['sessionId']]['events']==e
  assert 'This result is saved' in d['historyReport']['body']
 elif folder=='c2-drill':
  assert d['settled']['saveCalls']==1;assert d['settled']['chain'] is None;assert d['loadedEligibility'] is None;assert not d['comparisonAction'];assert not d['historyAction']
  assert next(x for x in d['after']['results'] if x['sessionId']==r['sessionId'])['events']==e
  assert r['sessionId'] not in d['reload']['state']['results'];assert d['observations']['replacementStateUnchanged'];assert d['observations']['replacementActivityUnchanged']
 else:
  assert d['settled']['saveCalls']==1;assert d['settled']['chain'] is None;assert not d['historyAction'];assert not d['comparisonAction'];assert r['sessionId'] not in d['reload']['state']['results']
  assert d['observations']['replacementStateUnchanged'];assert d['observations']['replacementActivityUnchanged'];assert d['deleted']['state']['installationId']!=d['pending']['state']['installationId']
 out.append({'case':folder,'events':len(e),'saveCalls':d['settled']['saveCalls'],'pass':True})
(root/'full-run-review.json').write_text(json.dumps(out,indent=2));print(out)
