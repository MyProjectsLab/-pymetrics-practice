import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile,writeFile} from 'node:fs/promises';
const {chromium}=createRequire(import.meta.url)('/Users/renzo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const F=JSON.parse(await readFile('/private/tmp/stop-m5-full-audit-c0fdc8e-20261001/fixtures.json'));
const before=JSON.parse(await readFile('/private/tmp/stop-m5-c5-repair/pre-edit/delivered-before-none-report-fail.json'));
const retained=before.settled.results.find(r=>r.mode==='retest'&&r.storageMode==='temporary_memory');
const origin='http://127.0.0.1:5527/';
const browser=await chromium.launch({headless:true,executablePath:'/Users/renzo/Library/Caches/ms-playwright/chromium_headless_shell-1208/chrome-headless-shell-mac-arm64/chrome-headless-shell'});
const out={browser:browser.version(),method:'Seed actual pre-edit immutable failed-save journal and verified prerequisites at the post-fallback boundary; actual App, training, storage and history controls. No timed run or save-retry claim for these matrix cases.',cases:[],errors:[]};
const click=(p,name)=>p.getByRole('button',{name,exact:true}).click();
const ready=p=>p.getByRole('button',{name:'Open Stop',exact:true}).waitFor();
const api=(p,fn,arg)=>p.evaluate(async({fn,arg})=>{const S=await import('/src/stop/storage.ts'),T=await import('/src/stop/training.ts'),R=await import('/src/stop/run.ts');return new Function('S','T','R','s','x',`return (${fn})(S,T,R,s,x)`)(S,T,R,S.stopLocalStore()??window.auditStore,arg)},{fn:fn.toString(),arg});
const capture=p=>api(p,async(S,T,R,s)=>({body:document.body.innerText,chain:T.currentTrainingChain(),results:R.activeTabResults(),state:await s.read(),activity:await s.activities(),locks:await navigator.locks.query()}));
try {
for(const delivery of ['delivered','delayed','unavailable']) for(const deletion of ['baseline','drill','all','unrelated']) {
 const c=await browser.newContext({viewport:{width:1200,height:800}});
 await c.addInitScript(({delivery,F,retained})=>{window.fixture={F,retained};if(delivery==='unavailable')window.BroadcastChannel=undefined;
 if(delivery==='delayed'){const B=window.BroadcastChannel;window.messages=[];window.BroadcastChannel=class extends B{postMessage(m){window.messages.push(()=>super.postMessage(m))}}}}, {delivery,F,retained});
 const a=await c.newPage(),b=await c.newPage(); for(const p of [a,b])p.on('pageerror',e=>out.errors.push(String(e)));
 await a.route('**/src/main.tsx',async route=>{const response=await route.fetch();let body=await response.text();body=body.slice(0,body.indexOf('createRoot(document'))+`
 const S=await import('/src/stop/storage.ts'),T=await import('/src/stop/training.ts'),R=await import('/src/stop/run.ts');
 const {F,retained}=window.fixture; const s=await S.StopLocalStore.open();window.auditStore=s;
 await s.mutate(q=>{Object.assign(q,F.state);q.results[F.retest.sessionId]=F.retest;q.exposures[F.retest.form.id]={formId:F.retest.form.id,sessionId:F.retest.sessionId,exposedAtWall:F.retest.completedAtWall,visualProfile:'standard',deleted:false,certainty:'confirmed'}});
 S.setStopLocalStore(s);T.restoreTrainingChain(F.chain);S.setStopLocalStore(null);
 R.restoreStopRecords([F.baseline,retained],[]);T.updateTrainingChain({retest:retained,status:'complete',retestAttempts:[{sessionId:retained.sessionId,formId:retained.form.id,valid:true}]});
 createRoot(document.getElementById('root')).render(_jsxDEV(App,{storagePolicy:'temporary'},void 0,false,{},this));`;
 await route.fulfill({response,body});});
 await a.goto(origin);await ready(a);await b.goto(origin);await ready(b);
 await click(a,'Resume Stop training');await a.getByText('Overall accuracy changed from 25% to 25% (+0 percentage points).',{exact:true}).waitFor();
 await click(a,'Back to library');await ready(a);
 const row={delivery,deletion,before:await capture(a)};
 await click(b,'Stop history');
 if(deletion==='all'){await click(b,'Delete all Assessment Practice data');await b.getByRole('alertdialog').getByRole('button',{name:'Delete all local data',exact:true}).click()}
 else {const key=deletion==='baseline'?F.baseline.form.id:deletion==='drill'?F.chain.drillAttempts[0].drillId+' drill':F.retest.form.id;
 const target=b.locator('article.panel').filter({hasText:key}).first();await target.getByRole('button',{name:'Delete this result',exact:true}).click();await b.getByRole('alertdialog').getByRole('button',{name:'Delete this result',exact:true}).click()}
 await b.getByRole('alertdialog').waitFor({state:'detached'});await a.waitForTimeout(100);
 row.durable=await capture(b);await click(a,'Resume Stop training');
 if(deletion==='unrelated') {await a.getByText('Overall accuracy changed from 25% to 25% (+0 percentage points).',{exact:true}).waitFor();row.resumed=await capture(a);await click(a,'Back to library')}
 else {await a.getByRole('alert').filter({hasText:'Comparison unavailable'}).waitFor();row.resumed=await capture(a);assert(!row.resumed.body.includes('Overall accuracy changed'));assert.equal(row.resumed.chain,null)}
 assert.deepEqual(row.resumed.results.find(r=>r.sessionId===retained.sessionId),retained);
 assert(!row.durable.state.results[retained.sessionId]);
 await click(a,'Review temporary retest');await a.getByRole('heading',{name:'Your Stop practice result',exact:true}).waitFor();row.review=await capture(a);assert(!row.review.body.includes('This result is saved'));assert(!row.review.body.includes('View baseline comparison'));
 if(delivery==='delivered'&&deletion==='baseline')await a.screenshot({path:'/private/tmp/stop-m5-c5-repair/review-after-baseline.png'});
 await b.evaluate(()=>{for(const send of window.messages??[])send()});await a.waitForTimeout(100);row.late=await capture(a);assert.deepEqual(row.late.results.find(r=>r.sessionId===retained.sessionId),retained);
 // Remove the bootstrap injection before reload: only durable history restores.
 await a.unroute('**/src/main.tsx');await a.reload();await ready(a);row.reload=await capture(a);
 assert(!row.reload.results.some(r=>r.sessionId===retained.sessionId));assert.notEqual(row.reload.chain?.status,'complete');
 if(deletion==='all'){assert.notEqual(row.durable.state.installationId,row.before.state.installationId);assert.deepEqual(row.durable.state.results,{});assert.deepEqual(row.durable.state.chains,{});assert.deepEqual(row.durable.state.exposures,{});assert.deepEqual(row.durable.activity,[])}
 else if(deletion!=='unrelated'){assert(row.durable.state.retiredChains[F.chain.id]);assert(row.durable.state.deletedSessions[deletion==='baseline'?F.baseline.sessionId:F.chain.drillAttempts[0].id])}
 row.pass=true;out.cases.push(row);console.log(delivery,deletion,'PASS');await c.close();
}
assert.deepEqual(out.errors,[]);
}catch(e){out.error=String(e.stack);console.error(e);process.exitCode=1}finally{await writeFile('/private/tmp/stop-m5-c5-repair/resume-matrix.json',JSON.stringify(out,null,2));await browser.close()}
