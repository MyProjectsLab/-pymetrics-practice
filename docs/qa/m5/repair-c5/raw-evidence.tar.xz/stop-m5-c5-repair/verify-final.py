import json,pathlib
from journal import check
root=pathlib.Path(__file__).resolve().parent
out=[]
for name in ['final-full-after','final-c2-drill']:
 d=json.loads(next((root/name).glob('*.json')).read_text());assert not d.get('error'),d.get('error');assert not d['errors']
 r=next(r for r in d['pending']['results'] if r['mode']=='retest' and r['storageMode']=='temporary_memory');j=check(r)
 if name=='final-full-after':
  x=d['postFailureDeletion'];assert d['settled']['saveCalls']==2;assert x['resumed']['chain'] is None
  assert 'Overall accuracy changed' not in x['resumed']['body'];assert 'Comparison unavailable' in x['resumed']['body']
  review=x['review'];assert 'could not be saved' in review['body'];assert x['afterReload']['chain'] is None;assert r['sessionId'] not in x['durable']['state']['results']
 else:
  assert d['settled']['saveCalls']==1;assert d['settled']['chain'] is None;assert not d['comparisonAction'];assert not d['historyAction']
  review=d['temporaryReview'];assert 'could not be saved' not in review['body'];assert r['sessionId'] not in d['reload']['state']['results']
  assert d['observations']['replacementStateUnchanged'];assert d['observations']['replacementActivityUnchanged']
 assert 'View baseline comparison' not in review['body'];assert 'This result is saved' not in review['body']
 assert next(x for x in review['results'] if x['sessionId']==r['sessionId'])['events']==r['events']
 out.append({'capture':name,'saveCalls':d['settled']['saveCalls'],'pass':True,**j})
for name in ['resume-matrix','extra-boundaries']:
 d=json.loads((root/(name+'.json')).read_text());assert not d.get('error');assert not d['errors'];assert all(c['pass'] for c in d['cases'])
 out.append({'capture':name,'cases':len(d['cases']),'pass':True})
(root/'FINAL-REVIEW.json').write_text(json.dumps(out,indent=2));print(out)
