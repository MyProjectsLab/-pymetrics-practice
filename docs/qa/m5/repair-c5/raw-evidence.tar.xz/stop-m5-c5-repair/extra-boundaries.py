from pathlib import Path
p=Path('/private/tmp/stop-m5-c5-repair/resume-matrix.mjs').read_text()
start=p.index("for(const delivery of")
end=p.index(" const c=",start)
p=p[:start]+"for(const delivery of ['unavailable']) for(const deletion of ['read-unavailable','visible-deletion']) {\n"+p[end:]
a=p.index(" await click(a,'Back to library');await ready(a);")
b=p.index(" row.pass=true;out.cases.push(row);",a)
p=p[:a]+'''
 const row={delivery,deletion,before:await capture(a)};
 if(deletion==='read-unavailable') {
  await click(a,'Back to library');await ready(a);
  await api(a,(S,T,R,s)=>{window.realRead=s.read.bind(s);s.read=async()=>{throw Error('Injected authority read unavailable')}});
  await click(a,'Resume Stop training');await a.getByRole('alert').filter({hasText:'Comparison unavailable'}).waitFor();
  assert(!(await a.locator('body').innerText()).includes('Overall accuracy changed'));
  await click(a,'Review temporary retest');await a.getByRole('heading',{name:'Your Stop practice result',exact:true}).waitFor();
  row.unavailableBody=await a.locator('body').innerText();assert(!row.unavailableBody.includes('This result is saved'));
  await api(a,(S,T,R,s)=>{s.read=window.realRead});
  row.review=await capture(a);assert.deepEqual(row.review.results.find(r=>r.sessionId===retained.sessionId),retained);
  await click(a,'Back to library');await click(a,'Resume Stop training');
  await a.getByText('Overall accuracy changed from 25% to 25% (+0 percentage points).',{exact:true}).waitFor();row.recovered=await capture(a);
 } else {
  await click(b,'Stop history');const target=b.locator('article.panel').filter({hasText:F.baseline.form.id}).first();
  await target.getByRole('button',{name:'Delete this result',exact:true}).click();await b.getByRole('alertdialog').getByRole('button',{name:'Delete this result',exact:true}).click();
  await b.getByRole('alertdialog').waitFor({state:'detached'});
  await a.getByText('Overall accuracy changed from 25% to 25% (+0 percentage points).',{exact:true}).waitFor({state:'detached',timeout:3000});
  row.after=await capture(a);assert.equal(row.after.chain,null);assert.deepEqual(row.after.results.find(r=>r.sessionId===retained.sessionId),retained);
  await click(a,'Review temporary retest');await a.getByRole('heading',{name:'Your Stop practice result',exact:true}).waitFor();row.review=await capture(a);
 }
 await a.unroute('**/src/main.tsx');await a.reload();await ready(a);row.reload=await capture(a);assert(!row.reload.results.some(r=>r.sessionId===retained.sessionId));
''' + p[b:]
p=p.replace("resume-matrix.json","extra-boundaries.json")
Path('/private/tmp/stop-m5-c5-repair/extra-boundaries.mjs').write_text(p)
