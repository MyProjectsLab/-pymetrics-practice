import json, pathlib
p=pathlib.Path('/private/tmp/stop-m5-c5-repair/pre-edit/delivered-before-none-report-fail.json')
d=json.loads(p.read_text()); assert not d.get('error'),d.get('error')
x=d['postFailureDeletion']; r=[r for r in d['settled']['results'] if r['mode']=='retest' and r['storageMode']=='temporary_memory'][0]
assert d['settled']['saveCalls']==2
assert x['resumed']['chain']['status']=='complete'
assert 'Overall accuracy changed from 25% to 25%' in x['resumed']['body']
base=x['resumed']['chain']['baseline']['sessionId']
assert base not in x['durable']['state']['results']
assert base in x['durable']['state']['deletedSessions']
assert x['resumed']['chain']['id'] in x['durable']['state']['retiredChains']
assert r['sessionId'] not in x['durable']['state']['results']
assert x['resumed']['chain']['retest']['events']==r['events']
assert x['afterReload']['chain'] is None
out={'reproduced':True,'saveCalls':2,'events':len(r['events']),'counts':r['summarySnapshot']['counts'],'staleComparison':True,'durableRetired':True,'reloadCleared':True}
pathlib.Path('/private/tmp/stop-m5-c5-repair/pre-edit/REPRODUCTION.json').write_text(json.dumps(out,indent=2));print(out)
