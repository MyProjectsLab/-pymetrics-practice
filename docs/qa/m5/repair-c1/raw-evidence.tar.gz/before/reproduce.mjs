import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('.',import.meta.url)),F=JSON.parse(await readFile(process.env.M5_FIXTURES ?? '/private/tmp/stop-m5-c1-repair-20260930/fixtures.json'));
const {chromium}=createRequire(import.meta.url)('/Users/renzo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const browser=await chromium.launch({headless:true,executablePath:'/Users/renzo/Library/Caches/ms-playwright/chromium_headless_shell-1208/chrome-headless-shell-mac-arm64/chrome-headless-shell'});
const delivery='unavailable';
const out={browser:browser.version(),delivery,cases:[],errors:[]};

const click=(p,name)=>p.getByRole('button',{name,exact:true}).click();
const ready=p=>p.getByRole('button',{name:'Open Stop',exact:true}).waitFor();
const api=(p,fn,arg)=>p.evaluate(async({fn,arg})=>{const S=await import('/src/stop/storage.ts'),T=await import('/src/stop/training.ts'),R=await import('/src/stop/run.ts');return new Function('S','T','R','s','x',`return (${fn})(S,T,R,s,x)`)(S,T,R,(S.stopLocalStore()??window.auditStore),arg)},{fn:fn.toString(),arg});
async function prep(p){
 await click(p,'Resume Stop training');await click(p,'Try a new Stop sequence');await click(p,'Start retest');await click(p,'See the rule');await click(p,'Try examples');
 for(let i=0;i<4;i++){if(!(i%2))await p.keyboard.press('Space');await click(p,'Check example');await click(p,i===3?'Check my understanding':'Next example')}
 for(const[q,a]of[['What should you do when GO appears?','Press Space once.'],['What should you do when NO-GO appears?','Do nothing.'],['Can you respond after the symbol disappears?','Yes, until the response window closes.']])await p.getByRole('group',{name:q,exact:true}).getByLabel(a,{exact:true}).check();
 await click(p,'Check answers');await click(p,'Check your setup');await p.getByRole('checkbox',{name:'I’m using a laptop or desktop with a physical keyboard.'}).check();await click(p,'Run input check');await p.keyboard.press('Space');await click(p,'Continue to readiness');await p.evaluate(()=>history.pushState({},'',location.href));await click(p,'I’m ready');await p.getByRole('heading',{name:'Warm-up complete',exact:true}).waitFor({timeout:30000});
}

const origin=process.env.AUDIT_URL??'http://127.0.0.1:5387/',stage=process.env.STAGE??'after';
try {
 const c=await browser.newContext({viewport:{width:1200,height:800}});
 await c.addInitScript(()=>{window.BroadcastChannel=undefined;window.unhandled=[];addEventListener('unhandledrejection',e=>window.unhandled.push(String(e.reason)))});
 const a=await c.newPage(),b=await c.newPage();for(const p of[a,b])p.on('pageerror',e=>out.errors.push(String(e)));
 await a.goto(origin);await ready(a);await api(a,(S,T,R,s,F)=>s.mutate(q=>Object.assign(q,F.state)),F);await a.reload();await ready(a);await b.goto(origin);await ready(b);await prep(a);
 await api(a,(S,T,R,s,stage)=>{window.auditStore=s;window.trace=[];const confirm=s.confirm.bind(s);s.confirm=async(...args)=>{window.signal=args[4];window.trace.push('confirmation-called');if(stage==='after'){await confirm(...args);window.trace.push('transaction-committed')};window.held=true;await new Promise(r=>window.releaseHeld=r);window.released=true;if(stage==='before')await confirm(...args);window.trace.push('delivery-completed')}} ,stage);
 await click(a,'Start scored task');await a.waitForFunction(()=>window.held);
 let completeSeen=false;for(let i=0;i<1100;i++){completeSeen=await api(a,(S,T,R)=>R.activeTabResults().some(r=>r.mode==='retest'&&r.events.at(-1)?.type==='protection_ended'));if(completeSeen)break;await a.waitForTimeout(200)}assert(completeSeen,'full completed journal must exist');
 const capture=p=>api(p,async(S,T,R,s)=>({results:R.activeTabResults(),state:await s.read(),activity:await s.activities(),locks:await navigator.locks.query(),body:document.body.innerText,signalAborted:window.signal?.aborted??null,trace:window.trace,unhandled:window.unhandled,visibleButtons:[...document.querySelectorAll('button')].filter(e=>e.checkVisibility()).map(e=>e.textContent),brandVisibility:getComputedStyle(document.querySelector('.brand')).visibility,live:!!document.querySelector('.stop-live:not([hidden])')}));
 const complete=await capture(a),result=complete.results.find(r=>r.mode==='retest'&&r.events.at(-1)?.type==='protection_ended');assert(result);assert.equal(result.events.filter(e=>e.type==='stimulus_presented').length,88);
 await a.screenshot({path:root+stage+'-completed-stall.png'});
 const actions=[];
 try{await a.getByRole('button',{name:'Assessment Practice — game library',exact:true}).click({timeout:600});actions.push({action:'brand-click',clicked:true})}catch(e){actions.push({action:'brand-click',clicked:false,error:e.message})}
 await a.goBack();await a.waitForTimeout(150);actions.push({action:'native-same-document-back',snapshot:await capture(a)});
 await a.keyboard.press('Shift+Tab');await a.keyboard.press('Enter');await a.waitForTimeout(100);actions.push({action:'shift-tab-enter',snapshot:await capture(a)});
 await a.keyboard.press('Tab');await a.keyboard.press('Enter');await a.waitForTimeout(100);actions.push({action:'tab-enter',snapshot:await capture(a)});
 await click(b,'Stop history');await click(b,'Delete all Assessment Practice data');await b.getByRole('alertdialog').getByRole('button',{name:'Delete all local data',exact:true}).click();await a.waitForTimeout(1200);
 const waiting=await capture(a),dialogPending=await b.getByRole('alertdialog').count()===1;
 assert(dialogPending);assert(waiting.locks.held.length);assert(waiting.locks.pending.length);assert(waiting.live);assert(!waiting.state.results[result.sessionId]);assert.deepEqual(waiting.results.find(r=>r.sessionId===result.sessionId).events,result.events);
 if(stage==='after'){
   // Delivery release permits normal completion; deletion already queued wins afterward.
   await a.evaluate(()=>window.releaseHeld());await b.getByRole('alertdialog').waitFor({state:'detached',timeout:5000});await a.waitForTimeout(300);
   out.recovery={method:'release-injected-delivery',a:await capture(a),b:await capture(b)};
 }else{
   // A real document reload releases the lock by destroying its owning context.
   await a.reload();await ready(a);await b.getByRole('alertdialog').waitFor({state:'detached',timeout:5000});await a.waitForTimeout(200);
   out.recovery={method:'native-reload',a:await capture(a),b:await capture(b)};
 }
 out.stage=stage;out.origin=origin;out.complete=complete;out.actions=actions;out.waiting=waiting;out.dialogPending=dialogPending;out.observedCompletedUIStall=true;
 await c.close();
}catch(e){out.error=String(e.stack);process.exitCode=1;console.error(e)}finally{await writeFile(root+'completed-'+stage+'.json',JSON.stringify(out,null,2));await browser.close()}
