from pathlib import Path
import json, subprocess
A=Path(__file__).resolve().parent
rows=[]
for name in ['before-all-none-ordinary','after-drill-exit-ordinary']:
 d=json.loads((A/'final'/(name+'.json')).read_text());assert not d.get('error') and not d['errors']
 p=d['pending'];r=next(r for r in p['results'] if r['mode']=='retest');sid=r['sessionId'];fid=r['form']['id'];ev=r['events']
 assert not p['live'] and p['signalAborted'] and p['locks']=={'held':[],'pending':[]}
 assert 'Saving this result. It is not yet confirmed saved.' in p['body'] and 'This result is saved' not in p['body'];assert sid not in p['state']['results'];assert r['storageMode']=='temporary_memory'
 assert ev[-1]['type']=='protection_ended' and ev[-2]['type']=='session_completed';assert r['validity']=='valid'
 (A/'regressions'/('final-'+name+'-journal.json')).write_text(json.dumps(r))
 subprocess.run(['python3',str(A/'verify-ordinary.py'),'final-'+name+'-journal.json'],check=True)
 if 'failed' in d:
  f=d['failed'];assert f['saveCalls']==2;assert sid not in f['state']['results'];rr=next(x for x in f['results'] if x['sessionId']==sid);assert rr['events']==ev and rr['storageMode']=='temporary_memory' and rr['validity']=='valid';assert 'Your task data were recorded in this tab but could not be saved in this browser. Keep this tab open to review the result or continue the current training chain.' in f['body'];assert d['durable']['state']==d['late']['state'] and d['durable']['activity']==d['late']['activity']
 else:
  saved=d['saved'];assert saved['saveCalls']==(2 if name.endswith('retry') else 1);assert saved['state']['results'][sid]['events']==ev;assert saved['state']['exposures'][fid]['certainty']=='confirmed';assert sid not in saved['state']['reservations'];assert d['deleted']['state']==d['late']['state'] and d['deleted']['activity']==d['late']['activity'];assert d['late']['locks']=={'held':[],'pending':[]};assert next(x for x in d['after']['results'] if x['sessionId']==sid)['events']==ev
  if '-all-' in name:assert sid not in d['late']['state']['results'] and fid not in d['late']['state']['exposures']
  if '-drill-' in name:assert d['late']['state']['exposures'][fid]['certainty']=='confirmed';assert not d['late']['state']['activeChainId']
 rows.append({'case':name,'events':len(ev),'actualLocksEmpty':True,'immutableJournal':True,'lateBytesIdentical':True})
(A/'final-review.json').write_text(json.dumps(rows,indent=2));print('Reconciled',len(rows),'complete journals and held-delivery states')
