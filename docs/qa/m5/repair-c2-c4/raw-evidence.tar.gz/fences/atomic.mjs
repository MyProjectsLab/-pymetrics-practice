import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile,writeFile } from 'node:fs/promises';
const {chromium}=createRequire(import.meta.url)('/Users/renzo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const F=JSON.parse(await readFile(new URL('../fixtures.json',import.meta.url)));
const browser=await chromium.launch({headless:true,executablePath:'/Users/renzo/Library/Caches/ms-playwright/chromium_headless_shell-1208/chrome-headless-shell-mac-arm64/chrome-headless-shell'});
const out={cases:[],errors:[]};
try{for(const boundary of ['abort-after-put','success-twice']){
 const ctx=await browser.newContext();const p=await ctx.newPage();p.on('pageerror',e=>out.errors.push(String(e)));await p.goto('http://127.0.0.1:5407/');await p.getByRole('button',{name:'Open Stop',exact:true}).waitFor();
 const row=await p.evaluate(async({F,boundary})=>{
  const S=await import('/src/stop/storage.ts'),R=await import('/src/stop/run.ts');const s=S.stopLocalStore();
  await s.mutate(q=>{Object.assign(q,F.state);q.exposures[F.retest.form.id]={formId:F.retest.form.id,sessionId:F.retest.sessionId,exposedAtWall:F.retest.startedAtWall,visualProfile:'standard',certainty:'uncertain',deleted:false};q.reservations[F.retest.sessionId]={sessionId:F.retest.sessionId,formId:F.retest.form.id,chainId:F.chain.id,armed:true,family:'retest',ownerTabId:'audit',expiresAtMs:Date.now()+1800000}});
  const before={state:await s.read(),activity:await s.activities()};let trace=[],error=null;
  const native=IDBObjectStore.prototype.put;
  if(boundary==='abort-after-put')IDBObjectStore.prototype.put=function(value,...rest){const request=native.call(this,value,...rest);if(value?.results?.[F.retest.sessionId]){const tx=this.transaction;trace.push({result:true,confirmed:value.exposures[F.retest.form.id].certainty,relationship:value.attemptChains[F.retest.sessionId],reservation:!!value.reservations[F.retest.sessionId]});request.addEventListener('success',()=>{trace.push('result-put-success');tx.abort()});tx.addEventListener('abort',()=>trace.push('native-abort'))}return request};
  try{await s.saveResult(F.retest,F.chain.id)}catch(e){error=String(e)}finally{IDBObjectStore.prototype.put=native}
  const once={state:await s.read(),activity:await s.activities()};if(boundary==='success-twice')await s.saveResult(F.retest,F.chain.id);
  return{boundary,before,once,after:{state:await s.read(),activity:await s.activities()},trace,error,valid:R.verifyCompletedResult(F.retest)};
 },{F,boundary});assert(row.valid);
 if(boundary==='abort-after-put'){assert(row.error);assert(row.trace.includes('native-abort'));assert.deepEqual(row.after,row.before)}
 else {assert.equal(row.error,null);assert.deepEqual(row.once,row.after);assert.equal(row.after.state.attemptChains[F.retest.sessionId],F.chain.id);assert.equal(row.after.state.exposures[F.retest.form.id].certainty,'confirmed');assert(!row.after.state.reservations[F.retest.sessionId]);assert.deepEqual(row.after.state.results[F.retest.sessionId],F.retest);assert.equal(row.after.activity.filter(x=>x.sessionId===F.retest.sessionId&&x.type==='retest_exposed').length,1)}
 out.cases.push(row);await ctx.close();
}}catch(e){out.error=String(e.stack);process.exitCode=1}finally{await writeFile(new URL('atomic.json',import.meta.url),JSON.stringify(out,null,2));await browser.close()}
