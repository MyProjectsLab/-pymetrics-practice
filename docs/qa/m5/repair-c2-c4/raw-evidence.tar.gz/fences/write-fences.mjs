import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('.',import.meta.url)),F=JSON.parse(await readFile(process.env.M5_FIXTURES ?? '/private/tmp/stop-m5-c234-repair-20261001/fixtures.json'));
const {chromium}=createRequire(import.meta.url)('/Users/renzo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const browser=await chromium.launch({headless:true,executablePath:'/Users/renzo/Library/Caches/ms-playwright/chromium_headless_shell-1208/chrome-headless-shell-mac-arm64/chrome-headless-shell'});
const delivery='unavailable';
const out={browser:browser.version(),delivery,cases:[],errors:[]};

const click=(p,name)=>p.getByRole('button',{name,exact:true}).click();
const ready=p=>p.getByRole('button',{name:'Open Stop',exact:true}).waitFor();
const api=(p,fn,arg)=>p.evaluate(async({fn,arg})=>{const S=await import('/src/stop/storage.ts'),T=await import('/src/stop/training.ts'),R=await import('/src/stop/run.ts');return new Function('S','T','R','s','x',`return (${fn})(S,T,R,s,x)`)(S,T,R,(S.stopLocalStore()??window.auditStore),arg)},{fn:fn.toString(),arg});
try {
 for(const kind of ['ordinary','drill','baseline','result','all']){
  const c=await browser.newContext();const a=await c.newPage();await a.goto('http://127.0.0.1:5407/');await ready(a);
  const row=await api(a,async(S,T,R,s,x)=>{
   const {F,kind}=x;await s.mutate(q=>{Object.assign(q,F.state);q.exposures[F.retest.form.id]={formId:F.retest.form.id,sessionId:F.retest.sessionId,exposedAtWall:F.retest.startedAtWall,visualProfile:'standard',certainty:'uncertain',deleted:false};q.reservations[F.retest.sessionId]={sessionId:F.retest.sessionId,formId:F.retest.form.id,chainId:F.chain.id,armed:true,family:'retest',ownerTabId:'fixture',expiresAtMs:Date.now()+10000}});
   if(kind==='all'){await s.deleteAll();const fresh=await S.StopLocalStore.open();await fresh.reserve('replacement','baseline',0);fresh.close()}
   else if(kind!=='ordinary')await s.deleteResult(kind==='drill'?F.chain.drillAttempts[0].id:kind==='baseline'?F.baseline.sessionId:F.retest.sessionId);
   const before=await s.read(),beforeActivity=await s.activities();let error=null;try{await s.saveResult(F.retest,F.chain.id)}catch(e){error=e.constructor.name}
   return {kind,before,beforeActivity,after:await s.read(),afterActivity:await s.activities(),error,valid:R.verifyCompletedResult(F.retest)};
  },{F,kind});assert(row.valid);
  if(kind==='ordinary'){assert.equal(row.error,null);assert.equal(row.after.exposures[F.retest.form.id].certainty,'confirmed');assert.equal(row.after.attemptChains[F.retest.sessionId],F.chain.id);assert(!row.after.reservations[F.retest.sessionId]);assert.equal(row.afterActivity.filter(e=>e.type==='retest_exposed'&&e.sessionId===F.retest.sessionId).length,1)}
  else {assert(['DeletedChainError','InstallationClearedError'].includes(row.error));assert.deepEqual(row.before,row.after);assert.deepEqual(row.beforeActivity,row.afterActivity)}
  out.cases.push(row);await c.close();
 }
 out.pass=true;
}catch(e){out.error=String(e.stack);process.exitCode=1;console.error(e)}finally{await writeFile(root+'completion-write-fences.json',JSON.stringify(out,null,2));await browser.close()}
