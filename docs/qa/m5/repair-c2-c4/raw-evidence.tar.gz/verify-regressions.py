from pathlib import Path
import json,hashlib
A=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text())
def scored(d):
 events=d['events'];assert [e['sequenceNumber'] for e in events]==list(range(1,len(events)+1));assert all(e['sessionId']==d['sessionId'] for e in events);assert all(a['timestampMs']<=b['timestampMs'] for a,b in zip(events,events[1:]))
 phase=None;found=[]
 for e in events:
  if e['type']=='trial_scheduled':phase=e['payload']['trial']['phase']
  if e['type']=='stimulus_presented' and phase=='scored':
   assert e['payload']['confirmedOnsetMs']==e['timestampMs'];found.append(e)
 assert [e['payload']['stimulus'] for e in found]==d['realizedSequence']
 return found
out={'ordering':[],'f1':[],'cancellation':[]}
for delivery in ['delivered','delayed','unavailable']:
 summary=load(A/'regressions'/('matrix-'+delivery+'.json'));assert not summary.get('error') and not summary['errors'];assert len(summary['cases'])==15
 for r in summary['cases']:
  raw=load(A/'regressions/raw/stop-m5-audit-555288d/raw'/('ordering-'+delivery+'-'+r['point']+'-'+r['kind']+'.json'));id=r['claim']['sessionId'];d=next(d for d in raw['end']['drafts'] if d['sessionId']==id);actual=scored(d)
  expected=not(r['kind']!='unrelated' and r['point'] in ['before-arm','fixation','delete-first']);assert len(actual)==int(expected);assert d['status']=='invalid';state=raw['end']['state'];assert id not in state['reservations'];assert (r['claim']['formId'] in state['exposures'])==(expected and r['kind']!='all');assert raw['end']['active']==(r['kind']=='unrelated')
  if expected and r['kind']!='all':assert state['exposures'][r['claim']['formId']]['certainty']=='confirmed'
  if r['kind']=='unrelated':assert not raw['observed']['drafts']
  if r['point'] in ['present-first','after'] and expected:assert r['confirmations'][0]['at']<=raw['deletion']['committedAt']
  if r['kind']=='all':assert raw['replacement']==['InstallationClearedError']*5
  out['ordering'].append({'case':delivery+'/'+r['point']+'/'+r['kind'],'actualScoredEvents':len(actual),'eligible':raw['end']['active']})
f1=load(A/'regressions/audit-f1.json');assert not f1.get('error') and not f1['errors'];assert len(f1['cases'])==7
for r in f1['cases']:
 if r['kind']=='unrelated':
  raw=load(A/'regressions/f1-unrelated-full/unrelated-state.json');id=raw['before']['id'];assert raw['durable']['chains'][id]['drillAttempts']==raw['before']['drillAttempts']==raw['active']['drillAttempts'];assert raw['deletedId'] not in raw['durable']['results'];out['f1'].append({'case':'unrelated/failed/True','journalsPreserved':True});continue
 raw=load(A/'regressions'/('f1-'+r['kind']+'-'+r['fault']+'-'+str(r['notifications']).lower()+'.json'));before=raw['before'];id=before['id'];assert id not in raw['durable']['chains'];assert raw['after']['active'] is None
 for j in before['drillAttempts'][1:]:
  retained=next(k for k in raw['retained'] if k['id']==j['id']);assert retained==j
  saved=next((k for k in raw['durable']['retiredChains'][id]['drillAttempts'] if k['id']==j['id']),None)
  assert (saved is None) if j['id']==r.get('intentionallyDeleted') else saved==j
 out['f1'].append({'case':r['kind']+'/'+r['fault']+'/'+str(r['notifications']),'journalsPreserved':True})
assert f1['savedJournalDisclosure']['savedInOtherTab'];assert 'retained only in this tab' not in f1['savedJournalDisclosure']['visible']
for kind in ['read-pending','confirm-pending']:
 raw=load(A/'regressions'/('candidate-'+kind+'.json'));assert not raw['blockedAfterCancellation'];assert not raw['before']['locks']['held'] and not raw['before']['locks']['pending'];d=next(d for d in raw['before']['drafts'] if d['sessionId']==raw['claim']['sessionId']);assert len(scored(d))==(kind=='confirm-pending');out['cancellation'].append({'case':kind,'onsets':len(scored(d)),'locksEmpty':True})
w=load(A/'regressions/watchdog-read-pending-cancel.json');assert w['beforeRelease']['deletionDone'];assert w['beforeRelease']['locks']=={'held':[],'pending':[]};out['cancellation'].append({'case':'watchdog','locksEmpty':True})

life=load(A/'regressions/liveness.json');assert not life.get('error') and not life['errors'];assert len(life['cases'])==24
out['fullCancellation']=[]
for r in life['cases']:
 raw=load(A/'regressions/raw/stop-m5-audit-555288d/raw'/('cancellation-'+r['label']+'.json'));expected=int(r['label'].startswith('confirm'))
 assert len(scored(raw['retained']))==expected
 assert raw['retained']['events']==raw['late']['draft']['events']
 assert raw['replacement']['state']==raw['after']['state'] and raw['replacement']['activity']==raw['after']['activity']
 assert raw['before']['locks']=={'held':[],'pending':[]} and raw['after']['locks']=={'held':[],'pending':[]}
 assert raw['claim']['sessionId'] not in raw['before']['state']['reservations']
 assert (raw['claim']['formId'] in raw['before']['state']['exposures'])==(expected and not r['label'].endswith('all'))
 assert any(e['type']=='session_invalidated' for e in raw['retained']['events'])
 out['fullCancellation'].append({'case':r['label'],'onsets':expected,'lateBytesIdentical':True})
(A/'regression-independent-review.json').write_text(json.dumps(out,indent=2));print({k:len(v) for k,v in out.items()})
