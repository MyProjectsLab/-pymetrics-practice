from pathlib import Path
import json
from journal import check
R=Path(__file__).parent/'before'; rows=[]
p=R/'pending-deletion/after-baseline-report-ordinary.json';d=json.loads(p.read_text());r=next(x for x in d['pending']['results'] if x['mode']=='retest');sid=r['sessionId']
assert d['settled']['saveCalls']==2 and d['settled']['chain']['status']=='complete'
assert sid not in d['durable']['state']['results'] and d['loadedEligibility'] is None
assert d['comparisonAction']==1 and 'Baseline and retest' in d['comparison']['body']
rows.append(dict(finding='C2',source=str(p.relative_to(R)),reproduced=True,journal=check(r),facts='Typed baseline deletion retried twice, then temporary completed relationship and comparison despite absent durable result/chain'))
p=R/'pending-committed/after-commit-result-delete.json';d=json.loads(p.read_text());r=next(x for x in d['pending']['results'] if x['mode']=='retest');sid=r['sessionId']
assert sid in d['pending']['state']['results'] and sid not in d['late']['state']['results']
assert 'This result is saved in this browser.' in d['settled']['body'] and d['comparisonAction']==1
assert 'Baseline and retest' not in d['comparison']['body']
rows.append(dict(finding='C4',source=str(p.relative_to(R)),reproduced=True,journal=check(r),facts='Committed result deleted through history; delayed success restored saved claim and inert comparison'))
p=R/'two-retests/two-retests-late-first.json';d=json.loads(p.read_text());a,b=d['first'],d['second'];cid=d['after']['chain']['id']
assert d['beforeLate']['chain']['retest']['sessionId']==b['sessionId'] and d['after']['chain']['retest']['sessionId']==a['sessionId']
assert d['durable']['state']['chains'][cid]['retest']['sessionId']==a['sessionId']
assert 'Baseline and retest' not in d['afterCompareClick']['body']
for r in [a,b]:assert d['durable']['state']['results'][r['sessionId']]['events']==r['events']
rows.append(dict(finding='C3',source=str(p.relative_to(R)),reproduced=True,journals=[check(a),check(b)],facts='Ordinary second retest admitted; first late callback replaced second selected relationship and comparison stopped navigating'))
(R/'independent-review.json').write_text(json.dumps(rows,indent=2));print('Three pre-edit findings reproduced and raw journals independently checked')
