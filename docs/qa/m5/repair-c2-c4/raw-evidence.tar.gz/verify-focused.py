from pathlib import Path
import json,sys
from journal import check
R=Path(__file__).parent
F=json.loads((R/'fixtures.json').read_text()); cid=F['chain']['id']
warning='Your task data were recorded in this tab but could not be saved in this browser. Keep this tab open to review the result or continue the current training chain.'
rows=[]
for p in sorted((R/'focused').glob('*.json')):
 d=json.loads(p.read_text());label=p.stem
 try:
  assert not d.get('error') and not d['errors'],d.get('error')
  same=label.startswith('same-tab-');delivery,stage,deletion,action,mode=(label.removeprefix('same-tab-')).split('-')
  pending=d['pending'];r=next(x for x in pending['results'] if x['mode']=='retest' and x['sessionId']!=F['retest']['sessionId']);sid=r['sessionId'];form=r['form']['id'];journal=check(r)
  assert 'Saving this result. It is not yet confirmed saved' in pending['body'];assert not pending['live'];assert pending['signalAborted'];assert pending['locks']=={'held':[],'pending':[]}
  assert (sid in pending['state']['results'])==(stage=='after' and mode=='ordinary')
  settled=d['settled'];after=d['after'];state=d['late']['state'];reload=d['reload']['state'];cur=next((x for x in after['results'] if x['sessionId']==sid),None)
  assert settled['saveCalls']==(2 if same or mode in ['fail','retry'] else 1),settled['saveCalls']
  for key in ['pending','settled','after','late','reload']:
   assert not d[key]['unhandled'];assert d[key]['locks']=={'held':[],'pending':[]},key
  assert sid not in state['reservations'] or mode=='fail'
  if deletion in ['drill','baseline','result','all']:
   assert (settled['chain']==after['chain']==d['replacement']['chain']) if same else (settled['chain'] is None and after['chain'] is None)
   assert cid not in state['chains'];assert (d['loadedEligibility']['id']==d['replacement']['chain']['id']) if same else d['loadedEligibility'] is None
   assert d['comparisonAction']==0
   assert warning not in settled['body'] and warning not in after['body']
   if deletion in ['result','all']:
    assert cur is None and sid not in state['results'] and sid not in reload['results'];assert d['historyAction']==0
    assert 'This result is saved in this browser.' not in settled['body']
    if deletion=='result':assert state['exposures'][form]['deleted'] and 'sessionId' not in state['exposures'][form]
    else:
     assert state==d['deleted']['state'] and d['late']['activity']==d['deleted']['activity']
     assert state['installationId']!=pending['state']['installationId']
     assert 'replacement-audit' in state['reservations']
     if same:
      fresh=d['replacement']['chain']['baseline'];check(fresh)
      assert fresh in after['results'] and fresh==state['results'][fresh['sessionId']]
      assert after['chain']==d['replacement']['chain']
     else:assert len(d['late']['activity'])==1
    status='deleted; no review or comparison'
   else:
    assert cur and cur['events']==r['events'] and cur['summarySnapshot']==r['summarySnapshot']
    assert 'broken by deletion' in settled['body']
    assert state['exposures'][form]['certainty']=='confirmed' and not state['exposures'][form]['deleted']
    assert d['historyAction']==int(stage=='after')
    if stage=='before':
     assert sid not in state['results'] and cur['storageMode']=='temporary_memory'
     assert 'retained only in this tab for review' in settled['body'];assert 'This result is saved in this browser.' not in settled['body']
    else:
     assert state['results'][sid]==cur==reload['results'][sid]
     assert cur['storageMode']=='persistent_local';assert 'This result is saved in this browser.' in settled['body']
     assert 'Your Stop practice result' in d['historyReport']['body']
    # Nondeleted required journals remain byte-identical in retired storage.
    retired=state['retiredChains'][cid]
    for a in F['chain']['drillAttempts']:
     found=next((x for x in retired['drillAttempts'] if x['id']==a['id']),None)
     if deletion=='drill' and a['id']==F['chain']['drillAttempts'][0]['id']:assert found is None
     else:assert found==a
    status=('saved' if stage=='after' else 'tab-only')+' immutable review; chain retired'
  else:
   assert cur and cur['events']==r['events'] and cur['summarySnapshot']==r['summarySnapshot']
   assert settled['chain']['retest']['sessionId']==sid and settled['chain']['status']=='complete'
   assert d['comparisonAction']==1 and 'Baseline and retest' in d['comparison']['body']
   if mode=='fail':
    assert warning in settled['body'];assert cur['storageMode']=='temporary_memory'
    assert sid not in state['results'] and d['historyAction']==0
    status='single retry exhausted; exact warning; same-tab comparison'
   else:
    assert cur['storageMode']=='persistent_local';assert state['results'][sid]==cur==reload['results'][sid]
    assert state['chains'][cid]['retest']['sessionId']==sid;assert d['historyAction']==1
    assert 'Your Stop practice result' in d['historyReport']['body'];assert state['exposures'][form]['certainty']=='confirmed'
    if deletion=='unrelated':assert F['retest']['sessionId'] not in state['results']
    status='saved; comparison navigates; reload identical'
  rows.append(dict(case=label,outcome='PASS',detail=status,journal=journal,saveCalls=settled['saveCalls'],history=d['historyAction'],comparison=d['comparisonAction']))
 except Exception as e:
  rows.append(dict(case=label,outcome='FAIL',detail=str(e)));print('FAIL',label,repr(e));raise
(R/'focused-independent-review.json').write_text(json.dumps(rows,indent=2));print('Verified',len(rows),'full candidate cases')
