from pathlib import Path
import subprocess,os,json,concurrent.futures,threading,time
r=Path(__file__).parent
jobs=[]
def node(label,path,env={}):jobs.append((label,['node',str(r/path)],env))
def group(name):jobs.append((name,['python3',str(r/'run-suites.py'),name],{}))
node('overlap','overlap/probe.mjs',{'ACTION':'exit'})
group('cancellation')
for stage in ['before','after']:node('same-tab-all-'+stage,'focused/completion.mjs',dict(STAGE=stage,DELIVERY='unavailable',DELETION='all',ACTION='exit',DELETE_TAB='same'))
node('matrix-unavailable','regressions/matrix.mjs',{'DELIVERY':'unavailable'})
for stage in ['before','after']:
 for delivery in ['unavailable','delayed']:
  for deletion in ['drill','baseline','result','all']:
   action='none' if deletion=='all' else 'report'
   env=dict(STAGE=stage,DELIVERY=delivery,DELETION=deletion,ACTION=action)
   node('-'.join(env.values()),'focused/completion.mjs',env)
for stage,delivery in [('before','delayed'),('after','unavailable')]:node('unrelated-'+stage,'focused/completion.mjs',dict(STAGE=stage,DELIVERY=delivery,DELETION='unrelated',ACTION='report'))
for stage,mode in [('before','fail'),('after','retry')]:node('ordinary-failure-'+mode,'focused/completion.mjs',dict(STAGE=stage,DELIVERY='unavailable',DELETION='none',ACTION='report',SAVE_MODE=mode))
node('matrix-delivered','regressions/matrix.mjs',{'DELIVERY':'delivered'})
node('matrix-delayed','regressions/matrix.mjs',{'DELIVERY':'delayed'})
group('fast');group('ordinary')
node('atomic','fences/atomic.mjs');node('write-fences','fences/write-fences.mjs')
rows=[];lock=threading.Lock()
def run(job):
 label,cmd,extra=job;start=time.time()
 with (r/(label+'.log')).open('w') as f:
  try:code=subprocess.run(cmd,env=dict(os.environ,M5_FIXTURES=str(r/'fixtures.json'),**extra),stdout=f,stderr=subprocess.STDOUT,timeout=1400).returncode
  except subprocess.TimeoutExpired:code='timeout'
 with lock:
  rows.append(dict(label=label,code=code,seconds=round(time.time()-start,1)));(r/'run-status.json').write_text(json.dumps(rows,indent=2));print(rows[-1],flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as e:list(e.map(run,jobs))
