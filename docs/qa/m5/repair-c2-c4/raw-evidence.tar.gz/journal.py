from pathlib import Path
import json,hashlib
A=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text())
def check(r):
 e=r['events']; sid=r['sessionId']; assert all(x['sequenceNumber']==i+1 and x['sessionId']==sid for i,x in enumerate(e));assert all(a['timestampMs']<=b['timestampMs'] for a,b in zip(e,e[1:]));assert not any(x['type'] in ['timing_anomaly','session_invalidated','response_accepted'] for x in e)
 batches={};current=None
 for x in e:
  if x['type']=='trial_scheduled':
   t=x['payload']['trial'];current=(t['phase'],t['index']);assert current not in batches;batches[current]=[]
  if current is not None:batches[current].append(x)
 assert len([k for k in batches if k[0]=='warmup'])==8;assert len([k for k in batches if k[0]=='scored'])==80
 counts={'hits':0,'misses':0,'withholds':0,'falseAlarms':0};visible=[];lateness=[];previous=None
 for i,stim in enumerate(r['form']['sequence']):
  b=batches['scored',i]
  def one(t):
   xs=[x for x in b if x['type']==t];assert len(xs)==1,(sid,i,t,len(xs));return xs[0]
  onset,offset,timeout,resolved=[one(t) for t in ['stimulus_presented','stimulus_removed','trial_timed_out','trial_resolved']]
  a=onset['timestampMs'];z=offset['timestampMs'];d=timeout['payload']['deadlineMs'];v=z-a
  assert onset['payload']['stimulus']==stim and a==onset['payload']['confirmedOnsetMs'];assert z==offset['payload']['confirmedOffsetMs'];assert abs(v-offset['payload']['visibleDurationMs'])<1e-6
  assert d==a+1000 and resolved['payload']['resolvedAtMs']==d;assert resolved['payload']['triggerSequenceNumber']==timeout['sequenceNumber'];assert resolved['payload']['outcome']['kind']==('miss' if stim=='GO' else 'correct_withhold')
  assert abs(timeout['timestampMs']-d-timeout['payload']['latenessMs'])<1e-6
  if previous is not None:assert a>=previous+1200
  previous=max(d,z);visible.append(v);lateness.append(timeout['payload']['latenessMs']);counts['misses' if stim=='GO' else 'withholds']+=1
 assert counts==r['summarySnapshot']['counts']=={'hits':0,'misses':60,'withholds':20,'falseAlarms':0};assert r['summarySnapshot']['rates']=={'hit':0,'miss':1,'withhold':1,'falseAlarm':0,'overall':.25}
 assert r['summarySnapshot']['timing']['count']==0
 assert all(b['counts']=={'hits':0,'misses':15,'withholds':5,'falseAlarms':0} for b in r['summarySnapshot']['blocks'])
 end=one('batch_finished');assert end['timestampMs']>=previous+1200;assert e[-2]['type']=='session_completed' and e[-2]['payload']['eventCount']==len(e)-1 and e[-1]['type']=='protection_ended';assert r['validity']=='valid'
 return {'id':sid,'events':len(e),'counts':counts,'visibility':[min(visible),max(visible)],'deadlineLateness':[min(lateness),max(lateness)],'finalInterval':end['timestampMs']-previous,'journalSha256':hashlib.sha256(json.dumps(e,separators=(',',':'),sort_keys=True).encode()).hexdigest()}
