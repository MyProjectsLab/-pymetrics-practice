import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('.',import.meta.url)),F=JSON.parse(await readFile(process.env.M5_FIXTURES ?? '/private/tmp/stop-m5-c234-repair-20261001/fixtures.json'));
const {chromium}=createRequire(import.meta.url)('/Users/renzo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const browser=await chromium.launch({headless:true,executablePath:'/Users/renzo/Library/Caches/ms-playwright/chromium_headless_shell-1208/chrome-headless-shell-mac-arm64/chrome-headless-shell'});
const delivery='unavailable';
const out={browser:browser.version(),delivery,cases:[],errors:[]};

const click=(p,name)=>p.getByRole('button',{name,exact:true}).click();
const ready=p=>p.getByRole('button',{name:'Open Stop',exact:true}).waitFor();
const api=(p,fn,arg)=>p.evaluate(async({fn,arg})=>{const S=await import('/src/stop/storage.ts'),T=await import('/src/stop/training.ts'),R=await import('/src/stop/run.ts');return new Function('S','T','R','s','x',`return (${fn})(S,T,R,s,x)`)(S,T,R,(S.stopLocalStore()??window.auditStore),arg)},{fn:fn.toString(),arg});
async function prep(p){
 await click(p,'Resume Stop training');await click(p,'Try a new Stop sequence');await click(p,'Start retest');await click(p,'See the rule');await click(p,'Try examples');
 for(let i=0;i<4;i++){if(!(i%2))await p.keyboard.press('Space');await click(p,'Check example');await click(p,i===3?'Check my understanding':'Next example')}
 for(const[q,a]of[['What should you do when GO appears?','Press Space once.'],['What should you do when NO-GO appears?','Do nothing.'],['Can you respond after the symbol disappears?','Yes, until the response window closes.']])await p.getByRole('group',{name:q,exact:true}).getByLabel(a,{exact:true}).check();
 await click(p,'Check answers');await click(p,'Check your setup');await p.getByRole('checkbox',{name:'I’m using a laptop or desktop with a physical keyboard.'}).check();await click(p,'Run input check');await p.keyboard.press('Space');await click(p,'Continue to readiness');await p.evaluate(()=>history.pushState({},'',location.href));await click(p,'I’m ready');await p.getByRole('heading',{name:'Warm-up complete',exact:true}).waitFor({timeout:30000});
}

const origin=process.env.AUDIT_URL??'http://127.0.0.1:5407/', stage=process.env.STAGE??'before', deletion=process.env.DELETION??'all', action=process.env.ACTION??'none', saveMode=process.env.SAVE_MODE??'ordinary';
const label=[stage,deletion,action,saveMode].join('-');
async function until(fn,message){for(let i=0;i<120;i++){if(await fn())return;await new Promise(r=>setTimeout(r,50))}throw Error(message)}
async function keyboard(p,name){for(let i=0;i<30;i++){await p.keyboard.press('Tab');if(await p.evaluate(n=>document.activeElement?.textContent===n,name)){await p.keyboard.press('Enter');return}}throw Error('Keyboard could not reach '+name)}
const capture=p=>api(p,async(S,T,R,s)=>({results:R.activeTabResults(),state:await s.read(),activity:await s.activities(),locks:await navigator.locks.query(),body:document.body.innerText,signalAborted:window.signal?.aborted,trace:window.trace,unhandled:window.unhandled,chain:T.currentTrainingChain(),saveCalls:window.saveCalls,live:!!document.querySelector('.stop-live:not([hidden])')}));
try {
 const c=await browser.newContext({viewport:{width:1200,height:800}});
 await c.addInitScript(()=>{window.BroadcastChannel=undefined;window.unhandled=[];addEventListener('unhandledrejection',e=>window.unhandled.push(String(e.reason)))});
 const a=await c.newPage(),b=await c.newPage();for(const p of[a,b])p.on('pageerror',e=>out.errors.push(String(e)));
 await a.goto(origin);await ready(a);await api(a,(S,T,R,s,F)=>s.mutate(q=>Object.assign(q,F.state)),F);await a.reload();await ready(a);await b.goto(origin);await ready(b);await prep(a);
 await api(a,(S,T,R,s,x)=>{window.auditStore=s;window.trace=[];window.saveCalls=0;const confirm=s.confirm.bind(s),save=s.saveResult.bind(s);
 s.confirm=async(...args)=>{window.signal=args[4];window.trace.push('confirmation-called');if(x.stage==='after'){await confirm(...args);window.trace.push('confirmation-committed')};window.held=true;await new Promise(r=>window.releaseHeld=r);if(x.stage==='before')await confirm(...args);window.trace.push('confirmation-delivered')};
 s.saveResult=async(...args)=>{window.saveCalls++;if(window.saveCalls===1)await new Promise(r=>window.releaseSave=r);if(x.saveMode==='fail'||x.saveMode==='retry'&&window.saveCalls===1)throw Error('injected completion failure');await save(...args)};
 },{stage,saveMode});
 await click(a,'Start scored task');await a.waitForFunction(()=>window.held);
 let completeSeen=false;for(let i=0;i<1100;i++){completeSeen=await api(a,(S,T,R)=>R.activeTabResults().some(r=>r.mode==='retest'&&r.events.at(-1)?.type==='protection_ended'));if(completeSeen)break;await a.waitForTimeout(200)}assert(completeSeen,'full completion');
 await a.getByRole('heading',{name:'Stop complete',exact:true}).waitFor({timeout:2000});
 await until(()=>a.evaluate(()=>!!window.releaseSave),'completion write started independently');
 const pending=await capture(a),result=pending.results.find(r=>r.mode==='retest');assert(result);assert.equal(result.events.filter(e=>e.type==='stimulus_presented').length,88);assert.equal(result.events.filter(e=>e.type==='trial_resolved').length,88);assert.equal(result.validity,'valid');assert.equal(pending.live,false);assert.equal(pending.signalAborted,true);assert.deepEqual(pending.locks,{held:[],pending:[]});assert.match(pending.body,/Saving this result. It is not yet confirmed saved/);assert(!pending.body.includes('This result is saved'));assert(!pending.state.results[result.sessionId]);
 await a.screenshot({path:root+label+'-pending.png'});
 if(action!=='none'){
   await keyboard(a,'View my result');await a.getByRole('heading',{name:'Your Stop practice result',exact:true}).waitFor();
   const review=await capture(a);assert.match(review.body,/Saving this result. It is not yet confirmed saved/);assert(!review.body.includes('This result is saved'));out.review=review;
   if(action==='exit'){await keyboard(a,'Back to library');await ready(a);out.exit=await capture(a);assert.deepEqual(out.exit.results.find(r=>r.sessionId===result.sessionId).events,result.events);assert.deepEqual(out.exit.locks,{held:[],pending:[]})}
 }

 // Auditor case: delete while completion write has not begun its transaction.
 await click(b,'Stop history');
 if(deletion==='all') {await click(b,'Delete all Assessment Practice data');await b.getByRole('alertdialog').getByRole('button',{name:'Delete all local data',exact:true}).click()}
 else if(deletion==='result') {await api(b,(S,T,R,s,id)=>s.deleteResult(id),result.sessionId)}
 else {const key=deletion==='baseline'?F.baseline.form.id:F.chain.drillAttempts[0].drillId+' drill'; const row=b.locator('article.panel').filter({hasText:key}).first();await row.getByRole('button',{name:'Delete this result',exact:true}).click();await b.getByRole('alertdialog').getByRole('button',{name:'Delete this result',exact:true}).click()}
 await b.getByRole('alertdialog').waitFor({state:'detached',timeout:3000});
 if(deletion==='all')await api(b,async(S,T,R,s)=>{await s.reserve('replacement-audit','baseline',0);await s.activity({key:'replacement-audit',sessionId:null,chainId:null,type:'report_viewed',payload:{}})});
 await a.waitForTimeout(1200);
 out.label=label;out.pending=pending;out.deleted=await capture(b);out.beforeSettlement=await capture(a);
 await a.evaluate(()=>window.releaseSave());await a.waitForTimeout(1200);
 out.settled=await capture(a);out.durable=await capture(b);
 out.loadedEligibility=await api(b,async(S,T,R,s)=>S.inspectLocalState(await s.read()).activeChain);
 await a.screenshot({path:root+label+'-settled.png'});
 if(await a.getByRole('button',{name:'View my result',exact:true}).count()) await keyboard(a,'View my result');
 if(action==='exit'&&await a.getByRole('button',{name:'Resume Stop training',exact:true}).count()){await click(a,'Resume Stop training');await a.waitForTimeout(250);out.resumed=await capture(a)}
 const compare=a.getByRole('button',{name:'View baseline comparison',exact:true});
 out.comparisonAction=await compare.count();
 if(out.comparisonAction){await compare.click();await a.waitForTimeout(250);out.comparison=await capture(a);await a.screenshot({path:root+label+'-comparison.png'})}
 await a.evaluate(()=>window.releaseHeld());await a.waitForTimeout(400);
 out.late=await capture(b);out.after=await capture(a);
 out.observations={saveCalls:out.settled.saveCalls,chainStatus:out.settled.chain?.status,retainedValid:out.settled.results.find(x=>x.sessionId===result.sessionId)?.validity,
 replacementStateUnchanged:JSON.stringify(out.late.state)===JSON.stringify(out.deleted.state),replacementActivityUnchanged:JSON.stringify(out.late.activity)===JSON.stringify(out.deleted.activity),
 journalUnchanged:JSON.stringify(out.after.results.find(x=>x.sessionId===result.sessionId)?.events)===JSON.stringify(result.events)};
 await c.close();
}catch(e){out.error=String(e.stack);process.exitCode=1;console.error(e)}finally{await writeFile(root+label+'.json',JSON.stringify(out,null,2));await browser.close()}
