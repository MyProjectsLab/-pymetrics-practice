from pathlib import Path
import json,hashlib
A=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text())
def check(r):
 e=r['events']; sid=r['sessionId']; assert all(x['sequenceNumber']==i+1 and x['sessionId']==sid for i,x in enumerate(e));assert all(a['timestampMs']<=b['timestampMs'] for a,b in zip(e,e[1:]));assert not any(x['type'] in ['timing_anomaly','session_invalidated','response_accepted'] for x in e)
 batches={};current=None
 for x in e:
  if x['type']=='trial_scheduled':
   t=x['payload']['trial'];current=(t['phase'],t['index']);assert current not in batches;batches[current]=[]
  if current is not None:batches[current].append(x)
 assert len([k for k in batches if k[0]=='warmup'])==8;assert len([k for k in batches if k[0]=='scored'])==80
 counts={'hits':0,'misses':0,'withholds':0,'falseAlarms':0};visible=[];lateness=[];previous=None
 for i,stim in enumerate(r['form']['sequence']):
  b=batches['scored',i]
  def one(t):
   xs=[x for x in b if x['type']==t];assert len(xs)==1,(sid,i,t,len(xs));return xs[0]
  onset,offset,timeout,resolved=[one(t) for t in ['stimulus_presented','stimulus_removed','trial_timed_out','trial_resolved']]
  a=onset['timestampMs'];z=offset['timestampMs'];d=timeout['payload']['deadlineMs'];v=z-a
  assert onset['payload']['stimulus']==stim and a==onset['payload']['confirmedOnsetMs'];assert z==offset['payload']['confirmedOffsetMs'];assert abs(v-offset['payload']['visibleDurationMs'])<1e-6
  assert d==a+1000 and resolved['payload']['resolvedAtMs']==d;assert resolved['payload']['triggerSequenceNumber']==timeout['sequenceNumber'];assert resolved['payload']['outcome']['kind']==('miss' if stim=='GO' else 'correct_withhold')
  assert abs(timeout['timestampMs']-d-timeout['payload']['latenessMs'])<1e-6
  if previous is not None:assert a>=previous+1200
  previous=max(d,z);visible.append(v);lateness.append(timeout['payload']['latenessMs']);counts['misses' if stim=='GO' else 'withholds']+=1
 assert counts==r['summarySnapshot']['counts']=={'hits':0,'misses':60,'withholds':20,'falseAlarms':0};assert r['summarySnapshot']['rates']=={'hit':0,'miss':1,'withhold':1,'falseAlarm':0,'overall':.25}
 assert r['summarySnapshot']['timing']['count']==0
 assert all(b['counts']=={'hits':0,'misses':15,'withholds':5,'falseAlarms':0} for b in r['summarySnapshot']['blocks'])
 end=one('batch_finished');assert end['timestampMs']>=previous+1200;assert e[-2]['type']=='session_completed' and e[-2]['payload']['eventCount']==len(e)-1 and e[-1]['type']=='protection_ended';assert r['validity']=='valid'
 return {'id':sid,'events':len(e),'counts':counts,'visibility':[min(visible),max(visible)],'deadlineLateness':[min(lateness),max(lateness)],'finalInterval':end['timestampMs']-previous,'journalSha256':hashlib.sha256(json.dumps(e,separators=(',',':'),sort_keys=True).encode()).hexdigest()}
out={'parent':[],'pendingDeletion':[],'ordinaryFailure':[],'ordinary':[],'callback':[]}
for p in sorted((A/'parent-completion').glob('completed-*.json')):
 d=load(p);assert not d.get('error');r=next(r for r in d['complete']['results'] if r['mode']=='retest');v=check(r);assert d['waiting']['locks']['held'] and d['waiting']['locks']['pending'] and d['waiting']['live'];assert r['sessionId'] not in d['waiting']['state']['results'];assert next(x for x in d['waiting']['results'] if x['sessionId']==r['sessionId'])['events']==r['events'];v.update(file=str(p.relative_to(A)),blocked=True);out['parent'].append(v)
for p in sorted((A/'pending-deletion').glob('*.json')):
 d=load(p);assert not d.get('error');r=next(r for r in d['pending']['results'] if r['mode']=='retest');v=check(r);sid=r['sessionId'];assert d['pending']['locks']=={'held':[],'pending':[]} and not d['pending']['live'];assert 'not yet confirmed saved' in d['pending']['body'] and 'This result is saved' not in d['pending']['body'];assert d['settled']['saveCalls']==2;assert d['settled']['chain']['status']=='complete';assert d['settled']['chain']['retest']['sessionId']==sid;assert sid not in d['late']['state']['results'];assert d['late']['state']==d['deleted']['state'];assert next(x for x in d['after']['results'] if x['sessionId']==sid)['events']==r['events'];assert next(x for x in d['after']['results'] if x['sessionId']==sid)['summarySnapshot']==r['summarySnapshot'];assert not d['after']['unhandled'];assert d['after']['locks']=={'held':[],'pending':[]};v.update(file=str(p.relative_to(A)),durableEligibility=d['loadedEligibility'] is not None,memoryComplete=True,comparisonVisible='Baseline and retest' in d.get('comparison',d.get('resumed',{})).get('body',''));out['pendingDeletion'].append(v)
warning='Your task data were recorded in this tab but could not be saved in this browser. Keep this tab open to review the result or continue the current training chain.'
for p in sorted((A/'completion').glob('*.json')):
 d=load(p);assert not d.get('error');r=next(r for r in d['pending']['results'] if r['mode']=='retest');v=check(r);sid=r['sessionId'];f=d.get('failed',d.get('saved'));assert f['saveCalls']==2;rr=next(x for x in f['results'] if x['sessionId']==sid);assert rr['events']==r['events'] and rr['summarySnapshot']==r['summarySnapshot'];assert 'Your Stop practice result' in f['body'] and 'Stop complete' not in f['body'];assert d['pending']['locks']=={'held':[],'pending':[]};assert r['storageMode']=='temporary_memory'
 if 'failed' in d:assert warning in f['body'] and rr['storageMode']=='temporary_memory' and sid not in f['state']['results'] and 'This result is saved' not in f['body']
 else:assert rr['storageMode']=='persistent_local' and 'This result is saved' in f['body'] and d['reload']['state']['results'][sid]==f['state']['results'][sid] and not f['state']['reservations'].get(sid)
 v.update(file=str(p.relative_to(A)),status='failed' if 'failed' in d else 'saved',reportStayedOpen=True);out['ordinaryFailure'].append(v)
for name in ['completion-result.json','retest-completion-result.json']:
 p=A/'regressions'/name
 if p.exists():v=check(load(p));v['file']=str(p.relative_to(A));out['ordinary'].append(v)
for p in [A/'two-retests/two-retests-late-first.json',A/'fences/replacement-chain-callback.json',A/'pending-committed/after-commit-result-delete.json']:
 if p.exists():
  d=load(p);assert not d.get('error'),d.get('error');r=d.get('first') or next(r for r in d['pending']['results'] if r['mode']=='retest');v=check(r);v['file']=str(p.relative_to(A));v['observations']=d.get('observations',{});out['callback'].append(v)
d=load(A/'two-retests/two-retests-late-first.json');v=check(d['second']);first=d['first']['sessionId'];second=d['second']['sessionId'];chain=d['beforeLate']['chain']['id']
assert d['beforeLate']['chain']['retest']['sessionId']==second
assert d['afterLateSave']['chain']['retest']['sessionId']==first
assert d['durable']['state']['chains'][chain]['retest']['sessionId']==first
assert d['beforeLate']['state']['results'][second]==d['durable']['state']['results'][second]
assert d['beforeLate']['chain']['drillAttempts']==d['afterLateSave']['chain']['drillAttempts']
assert len({q['sessionId'] for q in d['afterLateSave']['chain']['retestAttempts']})==2
assert 'Your Stop practice result' in d['afterCompareClick']['body'] and 'Baseline and retest' not in d['afterCompareClick']['body']
out['secondRetest']=v
c=load(A/'pending-committed/after-commit-result-delete.json');sid=next(q['sessionId'] for q in c['pending']['results'] if q['mode']=='retest')
assert sid in c['pending']['state']['results'] and 'not yet confirmed saved' in c['pending']['body']
assert sid not in c['deleted']['state']['results'] and sid not in c['settled']['state']['results']
assert c['settled']['chain'] is None and c['loadedEligibility'] is None
assert 'This result is saved in this browser.' in c['settled']['body']
assert c['deleted']['state']==c['late']['state'] and c['deleted']['activity']==c['late']['activity']
out['staleSavedDisclosure']={'sessionId':sid,'durableResultAbsent':True,'savedClaimVisible':True,'chainCleared':True}
x=load(A/'fences/replacement-chain-callback.json');assert x['after']['chain']['id']=='replacement-chain-c1' and x['after']['chain']['retest'] is None
out['replacementChain']={'distinctChainGuard':True,'journalReloadEqual':x['reload']['state']['results']==x['after']['state']['results']}
(A/'completion-independent-review.json').write_text(json.dumps(out,indent=2));print({k:len(v) if isinstance(v,list) else 'verified' for k,v in out.items()})
