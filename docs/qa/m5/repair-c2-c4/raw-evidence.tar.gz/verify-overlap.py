from pathlib import Path
import json
from journal import check
R=Path(__file__).parent
d=json.loads((R/'overlap/two-retests-late-first.json').read_text());assert not d.get('error') and not d['errors']
a,b=d['first'],d['second'];cid=d['after']['chain']['id'];ids={a['sessionId'],b['sessionId']};state=d['durable']['state']
assert 'Retest complete' in d['blocked']['body'] and 'Start retest' not in d['blocked']['body'] and 'Try a new Stop sequence' not in d['blocked']['body']
for key in ['beforeLate','afterLateSave','after']:
 assert d[key]['chain']['retest']['sessionId']==b['sessionId'];assert d[key]['locks']=={'held':[],'pending':[]};assert not d[key]['unhandled']
assert state['chains'][cid]['retest']['sessionId']==b['sessionId']
assert set(x['sessionId'] for x in d['after']['chain']['retestAttempts'])==ids
assert set(x['sessionId'] for x in state['chains'][cid]['retestAttempts'])==ids
assert 'Baseline and retest' in d['afterCompareClick']['body']
for r in [a,b]:
 sid=r['sessionId'];current=next(x for x in d['after']['results'] if x['sessionId']==sid)
 assert current['events']==state['results'][sid]['events']==r['events'] and current['summarySnapshot']==r['summarySnapshot']
 assert state['attemptChains'][sid]==cid and sid not in state['reservations']
 assert state['exposures'][r['form']['id']]['sessionId']==sid and state['exposures'][r['form']['id']]['certainty']=='confirmed'
assert len([e for e in d['durable']['activity'] if e['type']=='retest_completed'])==1
rows=dict(outcome='PASS',journals=[check(a),check(b)],selected=b['sessionId'],ordinarySecondRetestBlocked=True,comparisonActuallyOpened=True,scope=d['overlapInjection'])
(R/'overlap-independent-review.json').write_text(json.dumps(rows,indent=2));print('Pending admission, both journals/exposures, newer relationship and actual comparison verified')
