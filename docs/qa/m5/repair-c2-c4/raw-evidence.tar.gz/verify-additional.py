from pathlib import Path
import json
from journal import check
R=Path(__file__).parent;D=R/'regressions';F=json.loads((R/'fixtures.json').read_text());rows=[]
def load(name,folder=D):
 d=json.loads((folder/(name+'.json')).read_text());assert not d.get('error') and not d.get('errors'),name;return d
def row(suite,case,detail):rows.append(dict(suite=suite,case=case,outcome='PASS',detail=detail))
eligibility=json.loads((D/'eligibility.json').read_text());assert len(eligibility)==24
for x in eligibility:
 expected=x['case'].endswith('unrelated');assert x['active']==expected and x['chains']==int(expected)
 assert len(x['invalid'])==int(not x['case'].endswith('all')) and not x['rejected']
 row('cancellation load eligibility',x['case'],'Current loader agrees with deletion scope and retained invalid attempt')
protocol=load('audit-protocol',D/'raw/stop-m5-audit-555288d/protocol');assert len(protocol['cases'])==13
for x in protocol['cases']:
 k=x['kind'];b=x['beforeRelease'];a=x['after'];assert a['locks']=={'held':[],'pending':[]} and a['deletionDone']
 expected=2 if k in ['present-first','later-storage-pending'] else 1 if k in ['frame-delay-200','confirm-reject','confirm-pending-cancel'] else 0
 assert len([e for e in a['events'] if e['type']=='stimulus_presented'])==expected
 if k in ['read-pending-cancel','confirm-pending-cancel']:assert b['deletionDone'] and b['locks']=={'held':[],'pending':[]}
 if k=='later-storage-pending':assert any(e['type']=='response_accepted' for e in b['snapshot']['events']) and any(e['type']=='trial_timed_out' for e in b['snapshot']['events'])
 row('presentation protocol',k,'Actual onsets, terminal lock state and deletion completion checked')
for x in load('transactions')['cases']:
 assert x['atDeletion']['aborted'];assert x['after']==x['replacement'];assert 'unexpected-commit' not in x['trace']
 assert x['atDeletion']['locks']=={'held':[],'pending':[]}
 row('native transaction cancellation',x['boundary']+'/'+x['kind'],'Aborted transaction; late delivery leaves replacement state/activity identical')
for x in load('atomic',R/'fences')['cases']:
 if x['boundary']=='abort-after-put':assert x['error'] and 'native-abort' in x['trace'] and x['before']==x['after']
 else:
  assert x['once']==x['after'];s=x['after']['state'];sid=F['retest']['sessionId'];cid=F['chain']['id']
  assert s['results'][sid]==F['retest'] and s['chains'][cid]['retest']==F['retest'];assert sid not in s['reservations'];assert s['exposures'][F['retest']['form']['id']]['certainty']=='confirmed'
  assert len([e for e in x['after']['activity'] if e['type']=='retest_exposed' and e['sessionId']==sid])==1
 row('completion atomicity',x['boundary'],'Result, selected relationship, confirmed exposure and activity reconcile atomically')
for x in load('completion-write-fences',R/'fences')['cases']:
 if x['kind']=='ordinary':assert x['after']['results'][F['retest']['sessionId']]==F['retest'] and x['after']['chains'][F['chain']['id']]['retest']==F['retest']
 else:assert x['error'] in ['DeletedChainError','InstallationClearedError'] and x['before']==x['after'] and x['beforeActivity']==x['afterActivity']
 row('completion write fence',x['kind'],'Captured transaction outcome and retained bytes checked')
for x in load('deletion-races')['cases']:
 assert (x['memoryAfterDelete']['id'] is not None)==(x['action']=='unrelated') and x['activeAfterReload']==int(x['action']=='unrelated')
 assert x['durableHash']==x['reloadHash']
 assert x['staleStorageReplay']==('accepted' if x['action']=='unrelated' else 'Error' if x['action']=='all' else 'DeletedChainError')
 assert x['unrelatedPreserved']==(x['action'] not in ['all','unrelated'])
 if x['action']=='drill':assert F['chain']['drillAttempts'][0]['id'] not in x['retainedAttemptIds']
 row('R1 deletion retry',x['failure']+'/'+x['action']+'/'+x['order'],'Deletion scope, reload hash, preserved unrelated result and late write outcome checked')
for x in load('reload-evidence')['cases']:
 valid=x['name'] in ['intact','timing-note','viewport-boundary','blur-999','blur-1000','unmatched-blur-1000','repeated-brief-blur','fixation-2','wrong_key-4','extra-9','repeat-20','pre-start-setting']
 assert x['admitted']==valid and x['activeChain']==valid and bool(x['memory'])==valid
 assert x['rawHashBefore']==x['rawHashAfter'];assert x['reportButtons']==(2 if x['mode']=='retest' and valid else 1 if valid or x['mode']=='retest' else 0)
 row('R2 load integrity',x['mode']+'/'+x['name'],'Independent eligibility expectation and preserved raw hash checked')
for x in load('initial-fixation-load')['cases']:
 valid=x['name'] in ['control','blur-1000','initial-fixation-2','initial-wrong-4']
 assert x['accepted']==valid and x['chain']==valid and x['memory']==valid and x['preserved']
 assert x['reports']==(1+int(valid) if x['mode']=='retest' else int(valid))
 row('F3 load integrity',x['mode']+'/'+x['name'],'Initial protected evidence and exact threshold/control eligibility checked')
b=load('regressions')['checks']
for x in b['preOnset']:
 assert x['available']==(6 if x['family']=='replay' else 4)-bool(x['onsets'])
 assert x['claimGone'] and x['retainedUnchanged'] and x['laterMarkerPreserved'] and x['deleted']
 row('B1',x['family']+'/'+str(x['onsets']),'Draft, consumption count and later exposure checked')
for x in b['resultMutations']:
 assert x['valid']==int(x['name']=='control') and x['chain']==(x['name']=='control') and x['preserved']
 row('B2',x['name'],'Rejected altered result metadata/evidence without rewriting stored bytes')
for x in b['drillMutations']:
 assert x['accepted']==(x['name'] in ['control','timingNote','extraNote']) and x['sourcePreserved']
 row('B3',x['name'],'Drill validity and source preservation checked')
assert len(b['profiles']['groups'])==2;row('B4','profiles','Two distinct compatible-profile chart groups')
assert len(b['autoRetry'])==2 and b['failureRetry']['retained']['attempts']==1 and b['failureRetry']['durableAttemptCount']==0 and b['failureRetry']['restoredAttempts']==1
assert b['deletionRetry']['chainsAfterRetry']==0 and b['deletionRetry']['visibleDrill']==0 and b['deletionRetry']['memoryCleared'];row('B5','retry/deletion','Single automatic retry, retained failure, explicit retry and no resurrection')
assert b['starts']['count']==2 and len(set(b['starts']['attemptIds']))==2 and b['starts']['zeroAtIntro'] and b['starts']['noReloadFabrication'];row('N1','drill starts','Two distinct actual-start IDs; no intro or reload fabrication')
assert b['crossTab']['claims'][0]['formId']!=b['crossTab']['claims'][1]['formId'];assert b['uncertain']['marker']['certainty']=='uncertain';row('claims','cross-tab','Distinct claims; uncertain marker preserved; N2 still open')
for name,file in [('baseline','completion-result'),('retest','retest-completion-result')]:
 r=json.loads((D/(file+'.json')).read_text());j=check(r);row('ordinary production',name,j)
load('completion-browser');load('retest-completion');load('pre-onset-browser')
(R/'additional-independent-review.json').write_text(json.dumps(rows,indent=2));print('Checked',len(rows),'additional cases')
