from pathlib import Path
import subprocess,os,json,datetime,sys,fcntl
r=Path('/private/tmp/stop-m5-c234-repair-20261001');d=r/'regressions';rows=[]
group=sys.argv[1]
tasks={
'matrix':[("matrix",{"DELIVERY":x}) for x in ['delivered','delayed','unavailable']],
'fast':[(x,{}) for x in ['audit-boundaries','deletion-races','deletion-edges','initial-fixation-load','reload-evidence','regressions','supplement','audit-f1','admission-edges','onset']],
'cancellation':[(x,{}) for x in ['f2c-candidate-reproduction','f2c-watchdog-reproduction','f2c-liveness','f2c-transactions','f2c-protocol','verify-eligibility']],
'ordinary':[(x,{'M5_PREVIEW_URL':'http://127.0.0.1:5408/' if x!='pre-onset-browser' else 'http://127.0.0.1:5407/'}) for x in ['completion-browser','retest-completion','pre-onset-browser']]
}[group]
lock=(r/(group+'.lock')).open('w');fcntl.flock(lock,fcntl.LOCK_EX)
existing=r/(group+'-status.json')
if existing.exists():
 prior=json.loads(existing.read_text())
 if len(prior)==len(tasks) and all(x['code']==0 for x in prior):
  print('Previously completed on unchanged final source:',group);sys.exit(0)
for name,extra in tasks:
 env=dict(os.environ,M5_FIXTURES=str(r/'fixtures.json'));env.update(extra)
 label=name+('-'+extra['DELIVERY'] if 'DELIVERY' in extra else '')
 start=datetime.datetime.now().isoformat()
 with (d/(label+'.log')).open('w') as f:
  try:code=subprocess.run(['node',str(d/(name+'.mjs'))],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=800).returncode
  except subprocess.TimeoutExpired:code='timeout'
 rows.append(dict(name=label,code=code,start=start,end=datetime.datetime.now().isoformat()));(r/(group+'-status.json')).write_text(json.dumps(rows,indent=2));print(label,code,flush=True)
