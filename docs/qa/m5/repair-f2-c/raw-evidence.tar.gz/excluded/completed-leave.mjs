import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFile,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('.',import.meta.url)),F=JSON.parse(await readFile(process.env.M5_FIXTURES ?? '/private/tmp/stop-m5-audit-53286f7/fixtures.json'));
const {chromium}=createRequire(import.meta.url)('/Users/renzo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const browser=await chromium.launch({headless:true,executablePath:'/Users/renzo/Library/Caches/ms-playwright/chromium_headless_shell-1208/chrome-headless-shell-mac-arm64/chrome-headless-shell'});
const delivery='unavailable';
const out={browser:browser.version(),delivery,cases:[],errors:[]};

const click=(p,name)=>p.getByRole('button',{name,exact:true}).click();
const ready=p=>p.getByRole('button',{name:'Open Stop',exact:true}).waitFor();
const api=(p,fn,arg)=>p.evaluate(async({fn,arg})=>{const S=await import('/src/stop/storage.ts'),T=await import('/src/stop/training.ts'),R=await import('/src/stop/run.ts');return new Function('S','T','R','s','x',`return (${fn})(S,T,R,s,x)`)(S,T,R,(S.stopLocalStore()??window.auditStore),arg)},{fn:fn.toString(),arg});
async function prep(p){
 await click(p,'Resume Stop training');await click(p,'Try a new Stop sequence');await click(p,'Start retest');await click(p,'See the rule');await click(p,'Try examples');
 for(let i=0;i<4;i++){if(!(i%2))await p.keyboard.press('Space');await click(p,'Check example');await click(p,i===3?'Check my understanding':'Next example')}
 for(const[q,a]of[['What should you do when GO appears?','Press Space once.'],['What should you do when NO-GO appears?','Do nothing.'],['Can you respond after the symbol disappears?','Yes, until the response window closes.']])await p.getByRole('group',{name:q,exact:true}).getByLabel(a,{exact:true}).check();
 await click(p,'Check answers');await click(p,'Check your setup');await p.getByRole('checkbox',{name:'I’m using a laptop or desktop with a physical keyboard.'}).check();await click(p,'Run input check');await p.keyboard.press('Space');await click(p,'Continue to readiness');await p.evaluate(()=>history.pushState({},'',location.href));await click(p,'I’m ready');await p.getByRole('heading',{name:'Warm-up complete',exact:true}).waitFor({timeout:30000});
}

try{
 const c=await browser.newContext({viewport:{width:1200,height:800}});await c.addInitScript(()=>{window.BroadcastChannel=undefined});const a=await c.newPage(),b=await c.newPage();for(const p of[a,b])p.on('pageerror',e=>out.errors.push(String(e)));
 await a.goto('http://127.0.0.1:5357/');await ready(a);await api(a,(S,T,R,s,F)=>s.mutate(q=>Object.assign(q,F.state)),F);await a.reload();await ready(a);await b.goto('http://127.0.0.1:5357/');await ready(b);await prep(a);
 await api(a,(S,T,R,s)=>{window.auditStore=s;window.held=false;const original=s.confirm.bind(s);s.confirm=async(...args)=>{window.held=true;window.signal=args[4];await new Promise(r=>window.releaseHeld=r);return original(...args)}});
 await click(b,'Stop history');await click(b,'Delete all Assessment Practice data');await click(a,'Start scored task');await a.waitForFunction(()=>window.held);
 let result;for(let i=0;i<2200;i++){result=await api(a,(S,T,R)=>R.activeTabResults().find(r=>r.mode==='retest'&&r.events.at(-1)?.type==='protection_ended'));if(result)break;await a.waitForTimeout(100)}assert(result,'completed immutable record');assert.equal(result.events.filter(e=>e.type==='stimulus_presented').length,88);
 const before=await api(a,async(S,T,R,s)=>({state:await s.read(),locks:await navigator.locks.query(),signalAborted:window.signal.aborted}));assert(before.locks.held.length);assert(!before.signalAborted);
 await a.getByRole('button',{name:'Assessment Practice — game library',exact:true}).focus();await a.keyboard.press('Enter');await ready(a);await a.waitForTimeout(80);const canceled=await a.evaluate(async()=>({locks:await navigator.locks.query(),aborted:window.signal.aborted}));assert(canceled.aborted);assert.equal(canceled.locks.held.length,0);canceled.state=await api(a,(S,T,R,s)=>s.read());assert(canceled.state.exposures[result.form.id],'actual consumption retained on library exit');assert(!canceled.state.reservations[result.sessionId]);
 await b.getByRole('alertdialog').getByRole('button',{name:'Delete all local data',exact:true}).click();await b.getByRole('alertdialog').waitFor({state:'detached',timeout:3000});await api(b,(S,T,R,s)=>s.reserve('replacement-completed','baseline',0));const replacement=await api(b,async(S,T,R,s)=>({state:await s.read(),activity:await s.activities()}));
 await a.evaluate(()=>window.releaseHeld());await a.waitForTimeout(200);const after=await api(b,async(S,T,R,s)=>({state:await s.read(),activity:await s.activities()}));assert.deepEqual(after,replacement);
 const retained=await api(a,(S,T,R,s,id)=>R.activeTabResults().find(r=>r.sessionId===id),result.sessionId);assert.deepEqual(retained.events,result.events);assert.equal(retained.storageMode,'temporary_memory');assert.equal(result.events.filter(e=>e.type==='session_invalidated').length,0);
 out.cases.push({result,before,canceled,replacement,after,retained});out.pass=true;assert.deepEqual(out.errors,[]);await c.close();
}catch(e){out.error=String(e.stack);console.error(e);process.exitCode=1}finally{await writeFile(root+'completed-leave.json',JSON.stringify(out,null,2));await browser.close()}
