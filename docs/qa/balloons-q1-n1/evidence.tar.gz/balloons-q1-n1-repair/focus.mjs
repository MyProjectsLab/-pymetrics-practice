import {createRequire} from 'node:module';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const {chromium}=createRequire(import.meta.url)('/Users/renzo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const D=process.env.BALLOONS_REPAIR_OUT, URL='http://127.0.0.1:4256';
const browser=await chromium.launch({headless:true,channel:'chrome'}),results=[];
const btn=(p,n)=>p.getByRole('button',{name:n,exact:true});
async function enabled(p,n){await p.waitForFunction(n=>[...document.querySelectorAll('button')].some(b=>b.textContent===n&&!b.disabled),n)}
async function key(p,n,k='Space'){await enabled(p,n);await btn(p,n).focus();await p.keyboard.press(k)}
async function read(p){return p.evaluate(async()=>{const q=indexedDB.open('assessment-practice-balloons-v1');const db=await new Promise(r=>q.onsuccess=()=>r(q.result));return new Promise(r=>{const tx=db.transaction('installation'),req=tx.objectStore('installation').get('root');tx.oncomplete=()=>{db.close();r(req.result)}})})}
async function seed(p,root){await p.evaluate(async root=>{const q=indexedDB.open('assessment-practice-balloons-v1',1);const db=await new Promise(r=>{q.onupgradeneeded=()=>q.result.createObjectStore('installation');q.onsuccess=()=>r(q.result)});await new Promise(r=>{const tx=db.transaction('installation','readwrite');tx.objectStore('installation').put(root,'root');tx.oncomplete=()=>{db.close();r()}})},root)}
async function capture(p,name,extra={}){const data={...extra,root:await read(p),text:await p.locator('main').innerText(),focus:await p.evaluate(()=>({tag:document.activeElement.tagName,text:document.activeElement.textContent?.slice(0,180)}))};await fs.writeFile(`${D}/${name}.json`,JSON.stringify(data,null,2));await fs.writeFile(`${D}/${name}.ax.txt`,await p.locator('main').ariaSnapshot());await p.screenshot({path:`${D}/${name}.png`,fullPage:true});return data}
async function run(name,fn){const c=await browser.newContext({hasTouch:true,viewport:{width:390,height:844}}),p=await c.newPage();p.setDefaultTimeout(10000);try{await p.goto(URL);results.push({name,status:'observed',...await fn(p,c)});}catch(e){results.push({name,status:'ERROR',error:String(e.stack)});await capture(p,`${name}-error`).catch(()=>{})}finally{await c.close();await fs.writeFile(`${D}/focus-results.json`,JSON.stringify({browser:browser.version(),results},null,2))}}
async function prep(p){await btn(p,'Open Balloons').click();for(const n of ['Try the worked example','Pump example','Pump example','Collect example','Check my understanding'])await key(p,n);await p.getByLabel('the 10 cents on this balloon; earlier 15 cents stays banked',{exact:true}).check();await p.getByLabel('no, earlier outcomes do not reveal the next exact burst pump',{exact:true}).check();for(const n of ['Submit answers','Check input and accessibility','Test Pump','Test Collect','Continue to readiness','Start Balloons practice'])await key(p,n);await enabled(p,'Collect')}

for(const kind of ['remaining','empty','all','failed-individual','failed-all'])for(const keyName of ['Space','Enter'])await run(`focus-${kind}-${keyName}`,async p=>{
 const fixture=JSON.parse(await fs.readFile(`${D}/fresh-pair.json`,'utf8')).root;await seed(p,fixture);await btn(p,'Open Balloons').click();await key(p,'Balloons history');await enabled(p,'Delete all Balloons data');
 if(kind==='empty'){await btn(p,'Delete this result').first().click();await p.waitForFunction(()=>document.querySelectorAll('.balloons-history-item').length===1);}
 const before=await read(p);const fail=kind.startsWith('failed');
 if(fail)await p.evaluate(()=>{const put=IDBObjectStore.prototype.put;IDBObjectStore.prototype.put=function(v,k){if(this.transaction.db.name==='assessment-practice-balloons-v1'){window.failedDeletes=(window.failedDeletes||0)+1;throw new DOMException('Injected deletion failure','QuotaExceededError');}return put.call(this,v,k)}});
 const all=kind.endsWith('all'),control=all?btn(p,'Delete all Balloons data'):btn(p,'Delete this result').first();await control.focus();await p.keyboard.press(keyName);
 if(fail){await p.waitForFunction(()=>window.failedDeletes>0);await enabled(p,'Delete all Balloons data');}
 else await p.waitForFunction(count=>document.querySelectorAll('.balloons-history-item').length===count&&[...document.querySelectorAll('button')].some(b=>b.textContent==='Delete all Balloons data'),kind==='remaining'?1:0);
 await p.waitForTimeout(1200);
 const result=await capture(p,`focus-${kind}-${keyName}`,{before,keyName,kind});
 result.statusTexts=await p.locator('[role=status]').allTextContents();result.focusVisible=await p.locator('h1').evaluate(e=>({active:e===document.activeElement,visible:e.matches(':focus-visible'),outline:getComputedStyle(e).outlineStyle,width:getComputedStyle(e).outlineWidth}));
 if(fail)assert.deepEqual(result.root,before);else if(all){assert.notEqual(result.root.installationId,before.installationId);assert.deepEqual(result.root.records,{});assert.deepEqual(result.root.tombstones,{})}else{assert.equal(result.root.installationId,before.installationId);assert.equal(Object.keys(result.root.records).length,Object.keys(before.records).length-1);assert.equal(Object.keys(result.root.tombstones).length,Object.keys(before.tombstones).length+1)}
 const passed=result.focusVisible.active&&result.focusVisible.visible&&result.focusVisible.outline!=='none'&&result.statusTexts.some(t=>fail?/could not be confirmed/i.test(t):/deleted/i.test(t));
 return {status:passed?'PASS':'FAIL-focus-or-announcement',focus:result.focus,focusVisible:result.focusVisible,statusTexts:result.statusTexts,rootUnchanged:fail?JSON.stringify(result.root)===JSON.stringify(before):null};
});
await browser.close();if(results.some(r=>r.status!=='PASS'))process.exitCode=1;
