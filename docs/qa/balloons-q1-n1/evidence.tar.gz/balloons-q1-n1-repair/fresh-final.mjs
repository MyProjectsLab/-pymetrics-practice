import {createRequire} from 'node:module';import fs from 'node:fs/promises';import assert from 'node:assert/strict';
const {chromium}=createRequire(import.meta.url)('/Users/renzo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const D=process.env.BALLOONS_REPAIR_OUT,URL='http://127.0.0.1:4256';
const browser=await chromium.launch({headless:true,executablePath:'/Users/renzo/Library/Caches/ms-playwright/chromium_headless_shell-1208/chrome-headless-shell-mac-arm64/chrome-headless-shell'});
const results=[],oracle=JSON.parse(await fs.readFile(`${D}/arithmetic-independent.json`,'utf8'));
const btn=(p,name)=>p.getByRole('button',{name,exact:true});
async function act(p,name){await btn(p,name).click()}
async function read(p){return p.evaluate(async()=>{const q=indexedDB.open('assessment-practice-balloons-v1',1);const db=await new Promise((res,rej)=>{q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)});return new Promise((res,rej)=>{const t=db.transaction('installation','readonly');const r=t.objectStore('installation').get('root');t.addEventListener('complete',()=>{db.close();res(r.result)});t.addEventListener('abort',()=>rej(t.error))})})}
async function write(p,root){await p.evaluate(async root=>{const q=indexedDB.open('assessment-practice-balloons-v1',1);const db=await new Promise(res=>{q.onupgradeneeded=()=>q.result.createObjectStore('installation');q.onsuccess=()=>res(q.result)});await new Promise(res=>{const t=db.transaction('installation','readwrite');t.objectStore('installation').put(root,'root');t.oncomplete=()=>{db.close();res()}})},root)}
async function setup(file='pair-BL1-RT1.json',silent=false){const c=await browser.newContext();await c.addInitScript(({silent})=>{
 if(silent)Object.defineProperty(window,'BroadcastChannel',{value:undefined,configurable:true});
 window.__audit={remaining:0,held:[],delay:0,reads:0,changes:[]};
 const d=Object.getOwnPropertyDescriptor(IDBTransaction.prototype,'oncomplete');
 Object.defineProperty(IDBTransaction.prototype,'oncomplete',{...d,set(fn){const tx=this;d.set.call(tx,function(ev){const a=window.__audit;if(tx.db.name==='assessment-practice-balloons-v1'&&tx.mode==='readonly'){a.reads++;if(a.remaining>0){a.remaining--;a.held.push(()=>fn.call(tx,ev));return}if(a.delay){setTimeout(()=>fn.call(tx,ev),a.delay);return}}fn.call(tx,ev)})}});
 },{silent});const p=await c.newPage();p.setDefaultTimeout(15000);const errors=[];p.on('pageerror',e=>errors.push(e.message));await p.goto(URL);const data=JSON.parse(await fs.readFile(`${D}/${file}`,'utf8'));await write(p,data.root);await act(p,'Open Balloons');await act(p,'Balloons history');await btn(p,'Open saved comparison').click();await p.locator('.balloons-comparison').waitFor();return {c,p,data,errors};}
async function observe(p){await p.evaluate(()=>{const a=window.__audit;a.changes=[];a.last=!!document.querySelector('.balloons-comparison');new MutationObserver(()=>{const v=!!document.querySelector('.balloons-comparison');if(v!==a.last){a.changes.push({at:performance.now(),visible:v,text:document.querySelector('main')?.innerText});a.last=v}}).observe(document.querySelector('main'),{childList:true,subtree:true})})}
async function capture(p,name){await fs.writeFile(`${D}/${name}.root.json`,JSON.stringify(await read(p)));await fs.writeFile(`${D}/${name}.txt`,await p.locator('main').innerText());await p.screenshot({path:`${D}/${name}.png`,fullPage:true});}
async function run(name,fn){const t=Date.now();try{const details=await fn();results.push({name,status:'PASS',elapsedMs:Date.now()-t,...details});console.log('PASS',name)}catch(e){results.push({name,status:'FAIL',error:String(e.stack),elapsedMs:Date.now()-t});console.log('FAIL',name,String(e))}await fs.writeFile(`${D}/browser-results.json`,JSON.stringify({browser:browser.version(),results},null,2))}

const c=await browser.newContext(),p=await c.newPage(),errors=[];p.setDefaultTimeout(20000);p.on('pageerror',e=>errors.push(e.message));
async function key(name){const b=btn(p,name);await b.waitFor();await p.waitForFunction(name=>Array.from(document.querySelectorAll('button')).some(b=>b.textContent===name&&!b.disabled),name);await b.focus();await p.keyboard.press('Space')}
async function rounds(n,drill=false){for(let r=1;r<=n;r++){
 if(!drill)await p.waitForFunction(r=>document.querySelector('.balloons-play')?.textContent.includes(`Round ${r} of 39`)&&document.querySelector('[data-control=collect]')?.disabled===false,r);
 const intent=drill?0:n===39&&windowPolicy==='rt'?[0,1,4,32][r%4]:0;
 for(let k=0;k<intent;k++){await key('Pump');await p.waitForFunction(()=>document.querySelector('[data-control=collect]')?.disabled===false||!!document.querySelector('[data-next]'));if(await p.locator('[data-next]').count())break}
 if(!await p.locator('[data-next]').count())await key('Collect');
 if(r<n)await key(drill&&r%6===0?'Continue exercise':'Next balloon');
 }}
let windowPolicy='bl';
try{await p.goto(URL);await act(p,'Open Balloons');for(const name of ['Try the worked example','Pump example','Pump example','Collect example','Check my understanding'])await key(name);
await p.getByLabel('the 10 cents on this balloon; earlier 15 cents stays banked',{exact:true}).check();await p.getByLabel('no, earlier outcomes do not reveal the next exact burst pump',{exact:true}).check();for(const name of ['Submit answers','Check input and accessibility','Test Pump','Test Collect','Continue to readiness','Start Balloons practice'])await key(name);
await rounds(39);await key('View report');await key('Open assigned exercise');await key('Start assigned exercise');
for(let r=1;r<=18;r++){await key('Collect');if(r<18)await key(r%6===0?'Continue exercise':'Next balloon')}
await key('Open retest explanation');await key('Start 39-round retest');windowPolicy='rt';await rounds(39);await key('View report');await p.locator('.balloons-report').waitFor();const before=await read(p);const rt=Object.values(before.records).find(r=>r.header.retest);assert.equal(rt.snapshot.phase,'completed');await key('Open saved comparison');await p.locator('.balloons-comparison').waitFor();const after=await read(p);assert.deepEqual(after.records,before.records);await capture(p,'fresh-comparison');await fs.writeFile(`${D}/fresh-pair.json`,JSON.stringify({root:after,id:rt.header.identity.sessionId}));assert.deepEqual(errors,[]);console.log('PASS fresh BL39/drill18/RT39/report/comparison; journals unchanged');
}catch(e){console.log('FAIL',String(e.stack));await capture(p,'fresh-failure').catch(()=>{});process.exitCode=1}finally{await c.close();await browser.close()}
