import {createRequire} from 'node:module';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const {chromium}=createRequire(import.meta.url)('/Users/renzo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const D=process.env.BALLOONS_REPAIR_OUT, URL='http://127.0.0.1:4256';
const browser=await chromium.launch({headless:true,channel:'chrome'}),results=[];
const btn=(p,n)=>p.getByRole('button',{name:n,exact:true});
async function enabled(p,n){await p.waitForFunction(n=>[...document.querySelectorAll('button')].some(b=>b.textContent===n&&!b.disabled),n)}
async function key(p,n,k='Space'){await enabled(p,n);await btn(p,n).focus();await p.keyboard.press(k)}
async function read(p){return p.evaluate(async()=>{const q=indexedDB.open('assessment-practice-balloons-v1');const db=await new Promise(r=>q.onsuccess=()=>r(q.result));return new Promise(r=>{const tx=db.transaction('installation'),req=tx.objectStore('installation').get('root');tx.oncomplete=()=>{db.close();r(req.result)}})})}
async function seed(p,root){await p.evaluate(async root=>{const q=indexedDB.open('assessment-practice-balloons-v1',1);const db=await new Promise(r=>{q.onupgradeneeded=()=>q.result.createObjectStore('installation');q.onsuccess=()=>r(q.result)});await new Promise(r=>{const tx=db.transaction('installation','readwrite');tx.objectStore('installation').put(root,'root');tx.oncomplete=()=>{db.close();r()}})},root)}
async function capture(p,name,extra={}){const data={...extra,root:await read(p),text:await p.locator('main').innerText(),focus:await p.evaluate(()=>({tag:document.activeElement.tagName,text:document.activeElement.textContent?.slice(0,180)}))};await fs.writeFile(`${D}/${name}.json`,JSON.stringify(data,null,2));await fs.writeFile(`${D}/${name}.ax.txt`,await p.locator('main').ariaSnapshot());await p.screenshot({path:`${D}/${name}.png`,fullPage:true});return data}
async function run(name,fn){const c=await browser.newContext({hasTouch:true,viewport:{width:390,height:844}}),p=await c.newPage();p.setDefaultTimeout(10000);try{await p.goto(URL);results.push({name,status:'observed',...await fn(p,c)});}catch(e){results.push({name,status:'ERROR',error:String(e.stack)});await capture(p,`${name}-error`).catch(()=>{})}finally{await c.close();await fs.writeFile(`${D}/access-results.json`,JSON.stringify({browser:browser.version(),results},null,2))}}
async function prep(p){await btn(p,'Open Balloons').click();for(const n of ['Try the worked example','Pump example','Pump example','Collect example','Check my understanding'])await key(p,n);await p.getByLabel('the 10 cents on this balloon; earlier 15 cents stays banked',{exact:true}).check();await p.getByLabel('no, earlier outcomes do not reveal the next exact burst pump',{exact:true}).check();for(const n of ['Submit answers','Check input and accessibility','Test Pump','Test Collect','Continue to readiness','Start Balloons practice'])await key(p,n);await enabled(p,'Collect')}
await run('input-semantics',async p=>{
 await prep(p);const initial=await read(p),id=Object.keys(initial.records)[0],events=[];
 async function snap(label){await p.waitForTimeout(100);const r=(await read(p)).records[id];events.push({label,actionId:r.snapshot.core.nextActionId,phase:r.snapshot.phase,round:r.snapshot.core.round,focus:await p.evaluate(()=>document.activeElement.textContent),live:await p.locator('[aria-live]').allTextContents(),last:r.journal.at(-1)});return r}
 await snap('initial');await key(p,'Collect','Enter');await enabled(p,'Next balloon');await snap('enter-collect');assert.equal(await btn(p,'Next balloon').evaluate(e=>e===document.activeElement),true);
 await key(p,'Next balloon');await enabled(p,'Collect');await btn(p,'Collect').focus();await p.keyboard.down('Space');await p.keyboard.down('Space');await btn(p,'Pump').focus();await p.keyboard.up('Space');await snap('held-space-focus-transfer');assert.equal(events.at(-1).actionId,3);
 await btn(p,'Collect').tap();await enabled(p,'Next balloon');await snap('touch-collect');assert.equal(events.at(-1).last.command.action.source,'touch_or_pen');await key(p,'Next balloon');await enabled(p,'Collect');
 await btn(p,'Collect').evaluate(e=>e.click());await enabled(p,'Next balloon');await snap('unclassified-collect');assert.equal(events.at(-1).last.command.action.source,'unknown_or_assistive');await key(p,'Next balloon');await enabled(p,'Collect');
 await btn(p,'Collect').focus();await p.keyboard.down('Enter');await enabled(p,'Next balloon');await p.keyboard.down('Enter');await p.keyboard.up('Enter');await snap('held-enter-repeat-after-focus-transfer');assert.equal(events.at(-1).actionId,8);assert.equal(events.at(-1).round,4);
 const out=await capture(p,'input-semantics',{events});assert(out.root.records[id].snapshot.comparisonEligible);return {status:'PASS',events};
});
await browser.close();if(results.some(r=>r.status!=='PASS'))process.exitCode=1;
