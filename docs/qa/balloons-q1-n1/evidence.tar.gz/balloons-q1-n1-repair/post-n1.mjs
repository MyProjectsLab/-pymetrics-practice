import {createRequire} from 'node:module';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const {chromium}=createRequire(import.meta.url)('/Users/renzo/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const out=process.env.BALLOONS_REPAIR_OUT || '/private/tmp/balloons-b1b-repair/post';
const browser=await chromium.launch({headless:true,executablePath:'/Users/renzo/Library/Caches/ms-playwright/chromium_headless_shell-1208/chrome-headless-shell-mac-arm64/chrome-headless-shell'});
const results=[];
const url='http://127.0.0.1:4256';
const btn=(p,n)=>p.getByRole('button',{name:n,exact:true});
async function enabled(p,n){await p.waitForFunction(n=>[...document.querySelectorAll('button')].some(b=>b.textContent===n&&!b.disabled),n,{polling:10});}
async function click(p,n){await btn(p,n).click();}
async function read(p){return p.evaluate(async()=>{const db=await new Promise((r,j)=>{const q=indexedDB.open('assessment-practice-balloons-v1');q.onsuccess=()=>r(q.result);q.onerror=j});return new Promise((r,j)=>{const q=db.transaction('installation').objectStore('installation').get('root');q.onsuccess=()=>{db.close();r(q.result)};q.onerror=j;});});}
async function cur(p){return Object.values((await read(p)).records).at(-1);}
async function prep(p,open=true){if(open){await p.goto(url);await click(p,'Open Balloons');}for(const n of ['Try the worked example','Pump example','Pump example','Collect example','Check my understanding'])await click(p,n);await p.getByLabel('the 10 cents on this balloon; earlier 15 cents stays banked',{exact:true}).check();await p.getByLabel('no, earlier outcomes do not reveal the next exact burst pump',{exact:true}).check();for(const n of ['Submit answers','Check input and accessibility','Test Pump','Test Collect','Continue to readiness'])await click(p,n);}
async function hook(ctx,noBC=false){await ctx.addInitScript(({noBC})=>{
 if(noBC==='absent')Object.defineProperty(window,'BroadcastChannel',{value:undefined,configurable:true});
 const a=window.audit={hold:null,held:[],fail:[],readDelay:0,writes:[],dom:[],keys:[],holdReads:0,readHeld:[]};
 a.bcHeld=[]; if(noBC==='delayed'){const b=Object.getOwnPropertyDescriptor(BroadcastChannel.prototype,'onmessage');Object.defineProperty(BroadcastChannel.prototype,'onmessage',{...b,set(f){b.set.call(this,e=>a.bcHeld.push(()=>f?.call(this,e)));}});}
 const kinds=new WeakMap(),put=IDBObjectStore.prototype.put;
 IDBObjectStore.prototype.put=function(v,k){if(this.transaction.db.name==='assessment-practice-balloons-v1'&&v?.records){const r=Object.values(v.records).at(-1),kind=r?.journal.at(-1)?.command?.kind??'assignment';kinds.set(this.transaction,kind);a.writes.push({kind,record:r,at:performance.now(),mounted:!!document.querySelector('.balloons-play')});if(a.fail.includes(kind))throw new DOMException('Independent injected put failure','QuotaExceededError');}return put.call(this,v,k);};
 const d=Object.getOwnPropertyDescriptor(IDBTransaction.prototype,'oncomplete');Object.defineProperty(IDBTransaction.prototype,'oncomplete',{...d,set(f){d.set.call(this,e=>{if(this.db.name==='assessment-practice-balloons-v1'){const deliver=()=>f?.call(this,e);if(a.hold&&a.hold===kinds.get(this)){a.hold=null;a.held.push(deliver);return;}if(this.mode==='readonly'&&a.holdReads>0){a.holdReads--;a.readHeld.push(deliver);return;}if(this.mode==='readonly'&&a.readDelay){setTimeout(deliver,a.readDelay);return;}}f?.call(this,e);});}});
 for(const t of ['keydown','keyup','click'])document.addEventListener(t,e=>a.keys.push({type:e.type,key:e.key,code:e.code,repeat:e.repeat,detail:e.detail,target:e.target?.textContent?.slice(0,50),at:performance.now()}),true);
 new MutationObserver(()=>{const play=document.querySelector('.balloons-play'),report=document.querySelector('.balloons-report');a.dom.push({at:performance.now(),play:!!play,report:!!report,heading:document.querySelector('h1')?.textContent,status:[...document.querySelectorAll('[role="status"],[role="alert"]')].map(x=>x.textContent),phase:a.writes.at(-1)?.record?.snapshot.phase});}).observe(document,{subtree:true,childList:true});
},{noBC});}
async function scenario(name,work,noBC=false){const ctx=await browser.newContext({viewport:{width:1280,height:900},hasTouch:true});await hook(ctx,noBC);const p=await ctx.newPage();try{const evidence=await work(p,ctx);results.push({name,...evidence});await fs.writeFile(`${out}/${name}.json`,JSON.stringify({evidence,root:await read(p),trace:await p.evaluate(()=>({writes:window.audit.writes.map(w=>({kind:w.kind,at:w.at,mounted:w.mounted,phase:w.record?.snapshot.phase,exposure:w.record?.snapshot.exposure})),dom:window.audit.dom,keys:window.audit.keys}))},null,2));await p.screenshot({path:`${out}/${name}.png`,fullPage:true});console.log(name,JSON.stringify(evidence));}catch(e){results.push({name,harnessError:e.stack});console.error(name,e);await p.screenshot({path:`${out}/${name}-error.png`,fullPage:true});}finally{await ctx.close();await fs.writeFile(out+'/notification-results.json',JSON.stringify(results,null,2));}}
try {
for(const notifications of ['delayed'])for(const held of (process.env.PROBE_ONE?['assignment']:['assignment','arm','confirm','action']))for(const deletion of (process.env.PROBE_ONE?['individual']:['individual','installation']))for(const order of (process.env.PROBE_ONE?['delete-first']:['delete-first','delivery-first']))await scenario(`notification-${notifications}-${held}-${deletion}-${order}`,async(p,ctx)=>{
 await prep(p);
 if(held==='action'){await click(p,'Start Balloons practice');await enabled(p,'Pump');await p.evaluate(()=>window.audit.hold='action');await click(p,'Pump');}
 else {await p.evaluate(k=>window.audit.hold=k,held);await click(p,'Start Balloons practice');}
 await p.waitForFunction(()=>window.audit.held.length===1,null,{polling:10});
 const before=await read(p),id=Object.keys(before.records)[0],record=before.records[id];
 if(held==='assignment'||held==='arm')assert.equal(await p.locator('.balloons-play').count(),0);
 if(held==='action') {assert.equal(record.snapshot.core.nextActionId,2);assert.match(await p.locator('.balloons-play').innerText(),/Current: 0 cents/);}
 if(order==='delivery-first'){await p.evaluate(()=>window.audit.held.splice(0).forEach(f=>f()));await enabled(p,held==='action'?'Next balloon':'Pump');}
 const q=await ctx.newPage();await q.goto(url);await click(q,'Open Balloons');await click(q,'Balloons history');
 const started=Date.now();await click(q,deletion==='individual'?'Delete this result':'Delete all Balloons data');
 while(Object.keys((await read(q)).records).length && Date.now()-started<2600)await q.waitForTimeout(25);
 assert.equal(Object.keys((await read(q)).records).length,0);
 const elapsedMs=Date.now()-started,deleted=await read(q),locks=await q.evaluate(()=>navigator.locks.query());if(process.env.PROBE_ONE)console.log(JSON.stringify({before,deleted,locks}));
 if(deletion==='individual'){assert.equal(deleted.installationId,before.installationId);assert.equal(deleted.tombstones[id].exposure,order==='delivery-first'?'form_exposed':record.snapshot.exposure);assert.equal(deleted.tombstones[id].chainId,record.header.identity.chainId)}
 else{assert.notEqual(deleted.installationId,before.installationId);assert.deepEqual(deleted.tombstones,{})}
 // Allow the origin's bounded authority poll to release its owner after delivery-first deletion.
 const releaseStart=Date.now(); let lockState;
 do {lockState=await q.evaluate(()=>navigator.locks.query());if(!lockState.held.some(l=>l.name.endsWith(':owner')))break;await q.waitForTimeout(25)}while(Date.now()-releaseStart<2600);
 assert(!lockState.held.some(l=>l.name.endsWith(':owner')));
 // Start an actual explicit replay before any stale delivery. Keep its full bytes stable.
 await click(q,'Practise again'); await prep(q,false); await click(q,'Start Balloons practice'); await enabled(q,'Pump');
 const replacement=await read(q);const newRecord=Object.values(replacement.records)[0];assert.notEqual(newRecord.header.identity.sessionId,id);
 assert.equal(newRecord.header.formId,'RP1');
 // Release old delivery only after the replacement is genuinely mounted and saved.
 await p.evaluate(()=>{window.audit.held.splice(0).forEach(f=>f());window.audit.bcHeld.splice(0).forEach(f=>f());});
 await p.waitForTimeout(100);const afterOldCallbacks=await read(q);assert.deepEqual(afterOldCallbacks,replacement);
 const pendingNotices=await q.evaluate(()=>window.audit.bcHeld.length);
 await q.evaluate(()=>window.audit.bcHeld.splice(0).forEach(f=>f()));await p.waitForTimeout(300);
 const afterStaleNotices=await read(q),replacementText=await q.locator('main').innerText();
 const replacementVisible=await btn(q,'Pump').isEnabled() && await q.locator('.balloons-play').count()===1 && replacementText.includes('Form RP1');
 const replacementUnchanged=JSON.stringify(afterStaleNotices)===JSON.stringify(replacement);
 await p.waitForTimeout(1100);assert.equal(await p.locator('.balloons-play').count(),0);
 const visible=await p.locator('main').innerText();assert(!visible.includes('Saved standalone baseline'));
 const beforeReload=await read(q);assert.deepEqual(beforeReload,replacement);await q.reload();await click(q,'Open Balloons');await click(q,'Balloons history');await btn(q,'Resume saved session').waitFor();assert.equal(await btn(q,'Resume saved session').count(),1);assert.equal(await btn(q,'Open saved report').count(),0);const afterReload=await read(q);assert.deepEqual(Object.keys(afterReload.records),Object.keys(beforeReload.records));assert.deepEqual(Object.values(afterReload.records)[0].snapshot.core,newRecord.snapshot.core);
 return {pass:replacementUnchanged && replacementVisible,replacementVisible,pendingNotices,afterOldCallbacks,afterStaleNotices,replacementText,replacementUnchanged,elapsedMs,locks,exposureBefore:record.snapshot.exposure,deletionRoot:deleted,replacementRoot:replacement,oldResponseDeliveryUnchanged:true,noScoredMountBeforeArmDelivery:held==='assignment'||held==='arm'?true:null,visible};
},notifications);

}finally{await browser.close()}
if(results.some(r=>r.harnessError||!r.pass))process.exitCode=1;
