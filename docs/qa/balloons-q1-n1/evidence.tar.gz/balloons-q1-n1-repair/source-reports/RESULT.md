# Balloons B3 — initial read-only qualification

**Partial; one new reproducible keyboard-focus defect. No browser/device environment is certified.**

Target: `b71783abdcae163424e2e057150eb949a33586f2`; parent: `8e4d754b8253356c1a3006d842abc3f5244227ea`. Date: 2026-10-04, America/New_York.

The founder accepted B2-C2 at this SHA as a development milestone within its independent audit scope in this chat. This record preserves that acceptance separately from implementation, developer tests, independent audit, B3 environment qualification and release. The repository tracker was deliberately left unchanged and still contains its historical pending-C2 wording.

See [acceptance and physical-test map](ACCEPTANCE-MAP.md), [initial identity](initial-identity.json), [final unchanged-source check](final-state.json), [packet hashes](packet.json), and [raw evidence inventory](evidence-hashes.json). All original 866 tracked files and the tested archived source remain unchanged; Git status remains clean. Checks used a fresh external `git archive` with copied dependencies and disposable browser profiles. No product, specification, tracker, repository test or dependency file was changed. No commit, push, analytics activation, deployment or release occurred.

## Separate historical audit limits

| Milestone | Independent audit retained | Boundaries preserved |
|---|---|---|
| B2-A | PASS at `abc5136eb2033eaa6b8345ad658bf057b581895e` | Headless router/drill arithmetic and authority only; original aggregate suite failed the unchanged Stop focus assertion OBS-1. No UI/storage/device qualification. |
| B2-B | Focused F1–F5 PASS at `d1a40ceded441491142dd1ccd6bb8b6c21afd796` | Tested durable training, deletion, ownership, native-default input and familiarity; no physical input, speech or device matrix. N1/OBS-1 stayed open. |
| B2-C1 | Focused F1–F2 PASS at `8e4d754b8253356c1a3006d842abc3f5244227ea` | Presentation-specific pause recovery and canceled-owner cleanup plus named adjacent regressions; no whole-B2/Balloons or environment verdict. |
| B2-C2 | PASS at this target | Saved comparison/admission and exercised production UI; independently tested pair identities and deletion/read boundaries. Neither physical qualification nor release. |

Byte-for-byte audit copies and their source paths/hashes are in `historical-audits/` and `audit-provenance.json`. Historical PASSes are not transferred to broader scopes by this report.

## Q1 — P2: keyboard focus is lost after history deletion

**Reproduced twice per action in installed Chrome 154.0.8037.95 automation, macOS 26.6.2 (25G83), at 390 × 844 CSS px.** The driver seeds an isolated context with the genuinely browser-generated BL1/RT1 chain retained by this pass; no fabricated session is used.

1. Open Balloons → Balloons history with the two saved endpoints present.
2. Focus the first `Delete this result` button (the newest RT1) and press native Space. In a fresh context, repeat using `Delete all Balloons data`.
3. Wait for actual IndexedDB commit, the rebuilt history controls and another 1.2 seconds.
4. Individual deletion correctly leaves one record. Delete all correctly leaves zero records and a replacement installation. In every case, `document.activeElement` is **BODY**, with no retained visible keyboard focus.

The current render clears `history` during both deletions, unmounting the focused control; the focus effect depends on step/selection/comparison status, which do not change here. Relevant code: `src/balloons/Journey.tsx:78`, `:175–185`, `:241–247`. This is a keyboard-orientation defect, not evidence of failed deletion or corrupted scoring. It conflicts with the Master Strategy's visible-focus/core-keyboard requirement. Native screen-reader speech impact remains untested. No code change is proposed or made in this qualification pass.

Evidence: [driver](access.mjs), [case results](access-results.json), and `delete-focus-{individual,all}-{1,2}.{json,png,ax.txt}`. Each JSON includes the complete resulting root, visible text and focused element.

## N1 — reproduced under the original injection model; still open

Reviewed and reran the historical notification-replacement driver against the exact target build. **16/16 cases reproduce**: assignment/arm/confirm/action delivery × individual/Delete all × deletion-first/delivery-first. There are no harness errors in this matrix.

After deletion, the second tab starts and durably confirms new RP1. Old transaction callback delivery preserves the entire populated replacement root in all cases. Releasing the separately held earlier deletion notification handler then pauses RP1, clears the current view and appends one `pause / ownership_or_deletion_changed` interruption. The core, mapping, confirmed exposure and comparison-eligibility value remain unchanged; no deleted record or old money is restored.

The callback uses the current controller rather than the originating session/effect lifetime (`Journey.tsx:65–69`). The injection holds an application callback **after native receipt**, including beyond effect cleanup/channel close. It does not prove that a closed native BroadcastChannel delivers such an event. Eight targeted controls—native versus absent notifications × assignment/action hold × individual/Delete all, deletion-first—preserved replacement bytes, **8/8**. These controls retain transaction-delivery instrumentation; they are not estimates of natural race frequency.

Disposition: **open scoped robustness observation; native reachability unestablished**, separately from Q1 and from stale-write resurrection. No universal replacement-byte invariance claim is valid under this injected callback model.

Evidence: [16-case driver](n1.mjs), [16-case raw results](n1/notification-results.json), [control driver](n1-controls.mjs), [8-case controls](n1-controls/notification-results.json). Individual JSONs retain before/after roots, application notification count, visible text and trace; screenshots accompany them. `n1.exit` is 1 because the expected replacement-invariance assertion fails in all 16 cases; this is not a clean PASS run.

## OBS-1 — separately investigated, not reproduced or closed

The original B2-A audit recorded `<body>` instead of the “Remember the Stop rule” heading at `src/stop/Journey.test.tsx:25`. Both that test and `src/stop/Journey.tsx` are byte-identical between the original B2-A SHA and this target. Two complete repository runs here pass **1,090 tests / 52 files**. Twenty separate unchanged `Journey.test.tsx` runs pass **20/20** (two tests each).

Source inspection shows asynchronous shortcut evidence followed by `setStep('reminder')`; heading focus occurs in a passive effect. The test awaits heading existence and immediately asserts focus, rather than awaiting focus itself. That is a plausible synchronization gap, **not an established explanation** for the historical failure. No delayed-effect injection was used to manufacture a reproduction, no test was weakened and no product fix was made. The B2-A failed aggregate remains a failed historical run. **OBS-1 stays open**, separate from Q1.

Evidence: `obs1-01.log` through `obs1-20.log`, [summary](obs1-results.json), [unchanged Stop diff](obs1-source-diff.txt), both aggregate logs and the retained B2-A audit. If it recurs, capture DOM insertion, focus call/focusin and assertion ordering in that failing run before assigning cause.

## Executed checks and limits

- `npm run check` passed twice: lint, 1,090 tests/52 files, Stop form/drill checks, TypeScript/application and disabled-analytics builds. `npm run balloons:check` passed all nine scored/seven drill inventories. Five frozen packet file hashes match the approved register; both JSON companions fully parse. The two inherited lint warnings, experimental SQLite and bundle-size warnings remain. Logs: `check.log`, `check-unsandboxed.log`, `manifests.log` and exit files.
- Fresh, unseeded full chains passed in Chromium headless **145.0.7632.6** and installed Chrome **154.0.8037.95 in headless mode**: preparation → 39-round BL1 → 18-round maintenance → 39-round RT1 → report → comparison. Separate primitive-journal reconciliation passed **78 scored rounds per chain / 156 total**; the 36 drill rounds are not included in that independent scored-round count. Every compared number/sample count matches the retained oracle. The Chrome journey also reopened comparison after history/reload with unchanged endpoint records. Neither run certifies physical keys or native browser UI.
- Installed Chrome completed that chain with emulated reduced motion and verbose announcements. Twenty-eight captures at 1280/320 CSS px across fourteen checkpoints show no document overflow or clipped sampled paragraph/button/heading/label bounds; sampled main buttons are at least 48.375 px high, and no active animations were observed. AX snapshots and screenshots are retained under `chrome/`. Actual browser zoom, native OS preference, contrast, speech and every error/exhaustion state remain unqualified.
- Focused Practice input checks passed: Enter collection; Next/Pump focus; held Space canceled across focus transfer; emulated touch; unknown DOM activation; held Enter/repeat after focus transfer; mixed input remains eligible. This is automated native-default behavior, not physical hardware attestation.
- Separate default/verbose successful-pump checks pass. Standard round-2 announcement stays unchanged on a successful Pump; verbose changes to current 5/banked 0 cents. Both use a polite atomic live region. AX/DOM content does not prove audible speech or an assistive user's successful interaction.

Fresh-chain files: `fresh-final.mjs`, `fresh.log`, `fresh-pair.json`, `fresh-comparison.*`, `fresh-arithmetic.json`; Chrome equivalents under `chrome/`. The reused independent Python oracle is retained as `reconcile_core.py`/`reconcile-fresh.py`. The older nine-pair `arithmetic-independent.json` is only a copied harness prerequisite, **not a new B3 result**.

The first sandboxed check appeared idle before finishing successfully; a second run was started with normal subprocess permissions and also passed. This was redundant execution, not a failure rerun. The localhost preview initially failed with sandbox EPERM, then ran with approved execution permissions. A separate build also passed. Source never changed between those runs. Production builds overlapped early browser setup but produced identical content; retained final build hashes identify the tested assets, which also byte-match the existing independent C2 audit build. No failed product run was discarded or repaired.

## Remaining gates and reproduction

The [map](ACCEPTANCE-MAP.md) enumerates browser/device, physical keyboard/touch, speech, native lifecycle, OS preferences, true zoom/reflow, claims and provenance work. Q1, N1 and OBS-1 remain separate open items. **Shared full-mock integration is an open dependency**; standalone recovery cannot certify mock resume/restart. B3, whole Balloons and release remain incomplete.

Recreate the external source with `git archive b71783abdcae163424e2e057150eb949a33586f2`; copy installed dependencies outside the repository, run the package checks and serve the production build at `http://127.0.0.1:4246`. Drivers retain their absolute output/runtime paths; copy the evidence packet to the recorded temporary path or adjust output constants before rerunning into a new evidence directory. Run `node fresh-final.mjs`, `python3 reconcile-fresh.py`, `node chrome/journey.mjs`, `python3 chrome/reconcile-fresh.py`, `node access.mjs`, and `node announcements.mjs`. Run notification drivers with `BALLOONS_REPAIR_OUT` set to separate existing output directories. Keep the original raw files intact. No change to product code is required to reproduce Q1 or N1.
