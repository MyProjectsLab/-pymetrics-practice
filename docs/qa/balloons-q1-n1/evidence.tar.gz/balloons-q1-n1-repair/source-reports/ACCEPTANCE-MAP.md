# Balloons B3 acceptance map

Target: `b71783abdcae163424e2e057150eb949a33586f2`. Date: 2026-10-04, America/New_York. **Partial qualification; no environment certified.**

Authority: Master Strategy §§6, 12, 14, 17; frozen Balloons V1.0 §§3, 5–11. B2-C2 founder acceptance is recorded from the opening instruction of this chat, within its independent audit scope. Earlier audits retain their own SHA and limits.

## Browser/device boundary

The Balloons packet requires an approved matrix but does not enumerate one. The only retained enumerated plan is `docs/qa/m6-c/QUALIFICATION-PLAN.md`, explicitly for Stop, with its own approval-provenance caveat. The rows below are provisional B3 test targets derived from that plan, **not a new Balloons support declaration**. Balloons permits untimed touch and assistive gameplay; Stop's content-only mobile restriction, physical-keyboard gate, minimum timed viewport and display-frequency requirements are not imported into Balloons.

| Environment | Available check / result now | Physical tester / remaining requirement |
|---|---|---|
| macOS 26.6.2, Apple Silicon, installed Chrome 154.0.8037.95 | Automated headless use of installed Chrome: full fresh BL1 → maintenance drill → RT1 → comparison → history/reload; input/layout checks | Native browser UI, physical keys, full Tab navigation, zoom, OS preferences and lifecycle; no row certification |
| macOS Safari | App present; no Safari journey in this pass | Native full Practice/training journey, storage/deletion, keyboard, VoiceOver, zoom and lifecycle |
| Windows 11 Chrome | No device available | Full journey plus physical keyboard, zoom and NVDA |
| Windows 11 Edge | No device available | Full journey, keyboard, zoom, accessibility and storage |
| Windows 11 Firefox | No device available | Full journey plus physical keyboard, zoom and NVDA |
| iPhone Safari | No physical device; desktop touch emulation only | Full untimed Practice/training touch journey, VoiceOver, rotation, pinch/text sizing, history/deletion |
| Android Chrome | No physical device; desktop touch emulation only | Full untimed Practice/training touch journey, TalkBack, rotation, sizing, history/deletion |
| Chromium headless 145.0.7632.6 | Fresh complete chain and N1 controls | Supplemental engine evidence only; not another qualified consumer environment |

Record full OS/browser/assistive-tool versions, device, input hardware, viewport and zoom for each real run. Balloons-specific rows and minimum-version policy remain to be confirmed; no older/future version coverage follows from this pass.

## Acceptance checks

| Area | Standalone Practice | Advanced Training | Current disposition / physical work |
|---|---|---|---|
| Complete journey and arithmetic | Guide, example, quiz, settings, BL/RP, 39-round report | Evidence card, assigned 18-round drill, actual RT, descriptive comparison | Two fresh BL1/maintenance/RT1 chains passed; 156 scored rounds reconciled. RP1 replacement starts exercised. Complete RP and all seven drill inventories retain historical evidence; no new full device-matrix coverage. |
| Keyboard | Native Space/Enter, focus after resolution/Next, repeat/focus-transfer guard | Same controls; feedback and retest navigation | Automated native defaults and focused guards pass. Full physical Tab/Shift+Tab order, focus visibility and held keys across all states remain. Deletion-focus defect Q1 is open. |
| Touch/pointer/unknown activation | One canonical action, correct source, mixed-source eligibility | Same action meaning and comparison profile | Emulated touch and unclassified click pass on Practice, pointer used in navigation. Full physical touch and assistive activation across drills/RT remain. |
| Screen reader | Type/current/banked/outcome; default polite round/resolution, verbose successful pumps | Exercise/demo/feedback and comparison accessible | AX snapshots and standard/verbose successful-pump DOM checks pass. Speech, reading order, no duplicate polling speech and recovery/delete announcements require NVDA/VoiceOver/TalkBack. |
| Reduced motion/non-color identity | Readiness stores preference; same action outcomes and text/pattern Type identity | Same settings through drill/RT | Chrome chain with emulated reduced-motion preference and verbose mode passes; 28 layout captures show zero active animations. Actual OS preference and visual distinction/contrast remain. |
| Reflow/zoom | Preparation, play, report, history and recovery usable | Exercise, RT, comparison and unavailable states usable | 28 captures at 1280/320 CSS px show no page overflow; sampled main buttons are at least 48.375 px high. Genuine 200% browser zoom and 400%/320-equivalent, text resizing and all error/empty/exhausted states remain. Viewport resizing is not browser zoom. |
| History/reload | Immutable results, exposure, correct saved/review labels | Same chain, actual BL/RT IDs, current-authority comparison | Chrome reload preserved endpoint records. Individual/Delete all remove expected data; keyboard focus fails. Physical/native lifecycle return remains. |
| Deletion/replacement races | Individual tombstones; Delete all resets exposure with warning; no stale resurrection | Deleted dependencies suppress comparison | Historical C2 audit retains its authority matrix. New N1 16/16 injected delayed-handler cases pause a replacement; 8/8 native/absent controls preserve bytes. N1 remains open. |
| Claims/originality | Simulated money, task-only descriptions, invitation authority | Uncalibrated forms, signed differences, no causal improvement/trait inference | Sampled visible copy retains approved limits; source uses CSS patterns. Complete provenance/rights and final claims/visual review remain, without inferring originality from appearance. |
| Full mock | RP only; restart fresh where available; resume between games | Mock never becomes BL or training baseline | **Open dependency on shared full mock**. No standalone result closes mock/whole-Balloons acceptance. |

## Physical run card

For each confirmed row, retain exact build hashes and environment evidence; complete the guide, a 39-round Practice result, assigned exercise, 39-round retest, comparison and reload; export raw journals and independently reconcile money/counts. Distribute all seven drill inventories across the qualification campaign. Exercise real keyboard/touch/assistive activation, held keys, focus changes, pause/resume, tab switch, minimize/lock/sleep and return; test storage errors and comparison/deletion from a second tab. Check both announcement modes, non-color identity, OS reduced motion, true browser zoom/reflow, empty/error/exhausted history and all deletion outcomes. Record tester actions versus tool input separately. None of those unchecked cells is a PASS by inheritance.
