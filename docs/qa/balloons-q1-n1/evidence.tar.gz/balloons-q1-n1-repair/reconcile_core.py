import json,pathlib,hashlib,statistics
D=pathlib.Path(__file__).parent
packet=json.loads((D/'source/docs/specifications/ASSESSMENT_PRACTICE_BALLOONS_FIXED_MANIFESTS_V1_0.json').read_text())
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
forms={m['id']:m for m in packet['scored']}
for m in [*packet['scored'],*packet['drills']]:
 assert hashlib.sha256(canon({k:v for k,v in m.items() if k!='sha256'})).hexdigest()==m['sha256']
def replay(record):
 h=record['header']; m=forms[h['formId']];mapping=h['identity']['mapping']; rows=[];a=s=bank=lost=0;resolved=False;roundno=1;actionid=1;confirmed=set();pending=None
 for seq,e in enumerate(record['journal'],1):
  assert e['sequenceNumber']==seq
  cmd=e['command'] or {};kind=cmd.get('kind')
  if kind=='confirm':confirmed.add(e['round'])
  if kind=='action_pending':pending=cmd['action']
  if kind!='action':continue
  act=cmd['action'];assert act==pending;pending=None
  assert act['actionId']==actionid;assert act['expectedRound']==roundno;assert act['expectedRevision']==actionid-1;actionid+=1
  assert e['pre']==dict(attemptedPumps=a,successfulPumps=s,currentCents=0 if resolved else 5*s,bankedCents=bank,lostCents=lost)
  if act['kind']=='next':
   assert resolved;roundno+=1;a=s=0;resolved=False
  else:
   assert not resolved and roundno in confirmed
   threshold=m['rounds'][roundno-1]['threshold'];profile=m['rounds'][roundno-1]['profile'];outcome=None;rb=rl=0
   if act['kind']=='collect':outcome='voluntary_collect';rb=5*s
   else:
    assert act['kind']=='pump';a+=1
    if a==threshold:outcome='burst';rl=5*s
    else:
     assert a<threshold;s+=1
     if s==32:outcome='cap_collect';rb=160
   if outcome:
    bank+=rb;lost+=rl;resolved=True
    rows.append(dict(round=roundno,profile=profile,visibleType=next(t for t,p in mapping.items() if p==profile),attemptedPumps=a,successfulPumps=s,voluntaryPoint=s if outcome=='voluntary_collect' else None,bankedCents=rb,lostCents=rl,outcome=outcome,censored=outcome!='voluntary_collect'))
  assert e['post']==dict(attemptedPumps=a,successfulPumps=s,currentCents=0 if resolved else 5*s,bankedCents=bank,lostCents=lost)
 assert confirmed==set(range(1,40));assert len(rows)==39;assert rows==record['snapshot']['core']['results'];assert bank==record['snapshot']['core']['bankedCents'];assert lost==record['snapshot']['core']['lostCents']
 for rs in [rows,*[[r for r in rows if r['visibleType']==t] for t in ['Type 1','Type 2','Type 3']]]:
  assert len(rs) in [13,39];assert sum(r['attemptedPumps'] for r in rs)==sum(r['successfulPumps'] for r in rs)+sum(r['outcome']=='burst' for r in rs)
  assert 5*sum(r['successfulPumps'] for r in rs)==sum(r['bankedCents']+r['lostCents'] for r in rs)
 return rows
keys=['bankedCents','lostCents','collectedCount','burstCount','voluntaryCount','capCount']
def stats(rs):return [sum(r['bankedCents'] for r in rs),sum(r['lostCents'] for r in rs),sum(r['outcome']!='burst' for r in rs),sum(r['outcome']=='burst' for r in rs),sum(r['outcome']=='voluntary_collect' for r in rs),sum(r['outcome']=='cap_collect' for r in rs)]
def diff(a,b):return dict(baseline=a,retest=b,delta=b-a)
def compare(root,rid):
 rt=root['records'][rid];bl=root['records'][rt['header']['retest']['baselineSessionId']];a=replay(bl);b=replay(rt);out=[]
 for label in ['All balloons','Type 1','Type 2','Type 3']:
  aa=[r for r in a if label=='All balloons' or r['visibleType']==label];bb=[r for r in b if label=='All balloons' or r['visibleType']==label]
  row=dict(label=label,denominator=len(aa));row.update({k:diff(x,y) for k,x,y in zip(keys,stats(aa),stats(bb))})
  if label!='All balloons':
   for segment,lo,hi,minimum in [('median',1,39,5),('early',1,13,3),('late',27,39,3)]:
    x=[r['successfulPumps'] for r in aa if r['outcome']=='voluntary_collect' and lo<=r['round']<=hi];y=[r['successfulPumps'] for r in bb if r['outcome']=='voluntary_collect' and lo<=r['round']<=hi]
    row[segment]=dict(baselineCount=len(x),retestCount=len(y),required=minimum,difference=diff(statistics.median(x),statistics.median(y)) if min(len(x),len(y))>=minimum else None)
  out.append(row)
 return out
