import json
from reconcile_core import D,compare
x=json.loads((D/'fresh-pair.json').read_text());rows=compare(x['root'],x['id']);text=(D/'fresh-comparison.txt').read_text()
for row in rows:
 for label,key,count in [('Banked cents','bankedCents',False),('Lost cents','lostCents',False),('Collected','collectedCount',True),('Burst','burstCount',True),('Voluntary','voluntaryCount',True),('Automatic cap','capCount',True)]:
  d=row[key];den='/'+str(row['denominator']) if count else '';delta=('+' if d['delta']>0 else '')+str(d['delta']);assert f"{label}: {d['baseline']}{den} → {d['retest']}{den}; RT − BL {delta}." in text
 for key in ['median','early','late']:
  if key not in row:continue
  v=row[key];assert f"BL {v['baselineCount']} observed, RT {v['retestCount']} observed (minimum {v['required']} each)." in text
(D/'fresh-arithmetic.json').write_text(json.dumps({'status':'PASS','rows':rows,'scoredRounds':78},indent=2));print('PASS fresh production comparison, 78 primitive scored rounds')
